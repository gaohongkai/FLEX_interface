﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
using System.Diagnostics;

namespace FLEX_interface
{
    public partial class Form1 : Form
    {
        Si form01 = new Si();
        Sw form02 = new Sw();
        Su form03 = new Su();
        Sfr form04 = new Sfr();
        Sr form05 = new Sr();
        Ss form06 = new Ss();
        LR form07 = new LR();
        LF form08 = new LF();
        LS form09 = new LS();
        CR form10 = new CR();
        CS form11 = new CS();
        MP form12 = new MP();
        ME form13 = new ME();

        public static string rMult01="1.0";
        public static string rMult02="0.2";
        public static string rMult03="4.0";
        public static string rMult04="1";
        public static string rMult05="F";
        public static string Peakr01="1.0";
        public static string Peakr02="1.0";
        public static string Peakr03="10.0";
        public static string Peakr04="1";
        public static string Peakr05="T";
        public static string Peakf01="1.0";
        public static string Peakf02="1.0";
        public static string Peakf03="10.0";
        public static string Peakf04="1";
        public static string Peakf05="T";
        public static string Fr01="0.0";
        public static string Fr02="0.0";
        public static string Fr03="0.2";
        public static string Fr04="0";
        public static string Fr05="F";
        public static string D01="0.0";
        public static string D02="0.0";
        public static string D03="1.0";
        public static string D04="0";
        public static string D05="F";
        public static string Gam01="1.0";
        public static string Gam02="1.e-1";
        public static string Gam03="10.0";
        public static string Gam04="1";
        public static string Gam05="F";
        public static string Peaks01="1.0";
        public static string Peaks02="1.0";
        public static string Peaks03="50.0";
        public static string Peaks04="1";
        public static string Peaks05="F";
        public static string eMult01="1.0";
        public static string eMult02="1.e-1";
        public static string eMult03="3.0";
        public static string eMult04="1";
        public static string eMult05="T";

        public static string Sumax01="200";
        public static string Sumax02="0.1";
        public static string Sumax03="1000";
        public static string Sumax04="1";
        public static string Sumax05="T";

        public static string Beta01="1.0E-02";
        public static string Beta02="1.e-2";
        public static string Beta03="1000";
        public static string Beta04="1";
        public static string Beta05="T";
        public static string Kf01="0.3";
        public static string Kf02="1.e-4";
        public static string Kf03="4.0";
        public static string Kf04="1";
        public static string Kf05="T";
        public static string alfaF01="1.0";
        public static string alfaF02="1.e-4";
        public static string alfaF03="10.0";
        public static string alfaF04="1";
        public static string alfaF05 = "T";
        public static string ETpar01 = "1.0";
        public static string ETpar02 = "1.e-1";
        public static string ETpar03 = "5.0";
        public static string ETpar04 = "1";
        public static string ETpar05 = "F";
        public static string Ks01 = "2.4E-05";
        public static string Ks02 = "1.e-7";
        public static string Ks03 = "1.e-2";
        public static string Ks04 = "1";
        public static string Ks05 = "T";
        public static string Imax01 = "15";
        public static string Imax02 = "1.e-2";
        public static string Imax03 = "0.0";
        public static string Imax04 = "1";
        public static string Imax05 = "T";
        public static string IRsmth01 = "1.e-1";
        public static string IRsmth02 = "1.e-3";
        public static string IRsmth03 = "1.0";
        public static string IRsmth04 = "1";
        public static string IRsmth05 = "F";
        public static string Pmx01 = "0.0";
        public static string Pmx02 = "0.0";
        public static string Pmx03 = "10.0";
        public static string Pmx04 = "0";
        public static string Pmx05 = "F";
        public static string Kr01 = "4.1E-01";
        public static string Kr02 = "1.e-2";
        public static string Kr03 = "4.0";
        public static string Kr04 = "1";
        public static string Kr05 = "T";
        public static string Center01 = "0.5";
        public static string Center02 = "0.1";
        public static string Center03 = "1.0";
        public static string Center04 = "0";
        public static string Center05 = "F";
        public static string T0smth01 = "0.1";
        public static string T0smth02 = "1.e-2";
        public static string T0smth03 = "2.0";
        public static string T0smth04 = "0";
        public static string T0smth05 = "T";
        public static string Tmsmth01 = "0.3";
        public static string Tmsmth02 = "1.e-2";
        public static string Tmsmth03 = "2.0";
        public static string Tmsmth04 = "1";
        public static string Tmsmth05 = "T";
        public static string Swsmth01 = "0.5";
        public static string Swsmth02 = "1.e-2";
        public static string Swsmth03 = "2.0";
        public static string Swsmth04 = "1";
        public static string Swsmth05 = "T";
        public static string T001 = "3.5";
        public static string T002 = "0.0";
        public static string T003 = "10.0";
        public static string T004 = "0";
        public static string T005 = "T";
        public static string Tm01 = "3.5";
        public static string Tm02 = "0.0";
        public static string Tm03 = "4.0";
        public static string Tm04 = "0";
        public static string Tm05 = "T";
        public static string wCorr01 = "1.0";
        public static string wCorr02 = "0.5";
        public static string wCorr03 = "3.0";
        public static string wCorr04 = "0";
        public static string wCorr05 = "T";
        public static string Kw01 = "2.2";
        public static string Kw02 = "1.e-2";
        public static string Kw03 = "10.0";
        public static string Kw04 = "1";
        public static string Kw05 = "T";
        public static string Ksmt01 = "0.2";
        public static string Ksmt02 = "1.e-2";
        public static string Ksmt03 = "2.0";
        public static string Ksmt04 = "1";
        public static string Ksmt05 = "T";
        public static string EFSsm01 = "0.5";
        public static string EFSsm02 = "1.e-2";
        public static string EFSsm03 = "2.0";
        public static string EFSsm04 = "1";
        public static string EFSsm05 = "F";
        public static string Km01 = "9e-005";
        public static string Km02 = "1.e-6";
        public static string Km03 = "1.e-3";
        public static string Km04 = "1";
        public static string Km05 = "T";
        public static string Kp01 = "5e-003";
        public static string Kp02 = "5.0";
        public static string Kp03 = "100.0";
        public static string Kp04 = "1";
        public static string Kp05 = "T";
        public static string Sfb01 = "60.0";
        public static string Sfb02 = "5.0";
        public static string Sfb03 = "100.0";
        public static string Sfb04 = "1";
        public static string Sfb05 = "T";
        public static string alfaS01 = "1.0";
        public static string alfaS02 = "1.e-2";
        public static string alfaS03 = "10.0";
        public static string alfaS04 = "1";
        public static string alfaS05 = "T";

        public static bool formcheck1=false;
        public static bool formcheck2=false;
        public static bool formcheck3=false;
        public static bool formcheck4=false;
        public static bool formcheck5=false;
        public static bool formcheck6=false;

        public static bool Sumaxcheck=false ;
        public static bool Betacheck=false ;
//        public static bool eMultcheck=false;
        public static bool Kfcheck =false;
        public static bool alfaFcheck =false;
        public static bool Centercheck=false;
        public static bool ETparcheck =false;
        public static bool Pmxcheck =false;
        public static bool EFSsmcheck=false;
        public static bool Kscheck=false;
        public static bool alfaScheck=false;
        public static bool T0smthcheck=false;
        public static bool Tmsmthcheck=false;
        public static bool Swsmthcheck =false;
        public static bool Kwcheck = false;
        public static bool wCorrcheck = false;
        public static bool Tmcheck = false;
        public static bool T0check = false;
        public static bool Krcheck = false;
        public static bool Ksmtcheck = false;
        public static bool Kmcheck = false;
        public static bool Kpcheck =false;
        public static bool Sfbcheck = false;
        public static bool Imaxcheck = false;
        public static bool IRsmthcheck = false;

        public static int  lagsmthLR = -1;
        public static int  lagsmthLF = 1;
        public static int  lagsmthLS = -1;
        public static int ConvolutionNumLR = 1;
        public static int ConvolutionNumLF = 100;
        public static int  ConvolutionNumLS = 1;

        public static string InitialSi = "0.0";
        public static string InitialSu = "100.0";
        public static string InitialSf = "0.0";
        public static string InitialSs = "10.0";
        public static string InitialSr = "0.0";
        public static string InitialSw = "10.0";
        public static string LowestSi = "0.0";
        public static string LowestSu = "0.0";
        public static string LowestSf = "0.0";
        public static string LowestSs = "0.0";
        public static string LowestSr = "0.0";
        public static string LowestSw = "0.0";
        public static string HighestSi = "10.0";
        public static string HighestSu = "1.e4";
        public static string HighestSf = "1.e4";
        public static string HighestSs = "1.e4";
        public static string HighestSr = "1.e4";
        public static string HighestSw = "1.e4";

        public static int  URFunA = 2;
        public static int URFunB = 1;
        public static int URFunE = 31;
        public static int URFunD = 0;
        public static int EIR = -1;
        public static int IRsmooth = 21;
        public static int FSFun = 2;

        public static int activePar=0;
        public static int deadPar;
        public static int reservoirs=0;

        public Form1()
        {
            InitializeComponent();
        }

        public string fileDirectory = null;

       

        private void Form1_Load(object sender, EventArgs e)
        {
            
            string fileName = @"D:\TBMOS\path\WorkDirectory.inp";
            if (File.Exists(fileName))
            {
                StreamReader sr = new StreamReader(fileName, System.Text.Encoding.Default);
                fileDirectory = sr.ReadLine();
                sr.Close();

            }
 
         }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            this.pictureBox9.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox2.Visible = false;
                if (this.checkBox1.Checked == true && this.checkBox2.Checked==true)
                this.pictureBox2.Visible = true;
            if (this.checkBox1.Checked == true && this.checkBox2.Checked == false)
            {
                this.pictureBox8.Visible = true;
            }
            if (this.checkBox1.Checked == false && this.checkBox2.Checked == true)
            {
                this.pictureBox9.Visible = true;
            }
            if (this.checkBox1.Checked == true)
            {
                Si form01 = new Si();
                form01.Show();
                formcheck1 = true;
            }
            else
            {
                form01.Close ();
                formcheck1 = false;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            this.pictureBox9.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox2.Visible = false;
            if (this.checkBox1.Checked == true && this.checkBox2.Checked == true)
                this.pictureBox2.Visible = true;
            if (this.checkBox1.Checked == true && this.checkBox2.Checked == false)
            {
                this.pictureBox8.Visible = true;

            }
            if (this.checkBox1.Checked == false && this.checkBox2.Checked == true)
            {
                this.pictureBox9.Visible = true;
                
            }

            if (this.checkBox2.Checked == true)
            {
                Sw form02 = new Sw();
                form02.Show();
                formcheck2 = true;
            }
            else
            {
                form02.Close ();
                formcheck2 = false;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            
            if (this.checkBox3.Checked == true)
            {
                this.pictureBox3.Visible = true;
                Su form03 = new Su();
                form03.Show();
                formcheck3 = true;
            }
           else 
            {
                this.pictureBox3.Visible = false;
                form03.Close ();
                 formcheck3 = false;            
                }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox4.Checked == true)
            {
                this.checkBox7.Enabled = true;
                this.pictureBox4.Visible = true;
                Sfr form04 = new Sfr();
                form04.Show();
                formcheck4 = true;
            }
            else
            {
                this.checkBox7.Enabled = false;
                this.pictureBox4.Visible = false;
                form04.Close ();
                formcheck4 = false;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox5.Checked == true)
            {
                this.checkBox8.Enabled = true;
                this.pictureBox5.Visible = true;
                Sr form05 = new Sr();
                form05.Show();
                formcheck5 = true;
            }
            else
            {
                this.checkBox8.Enabled = false;
                this.pictureBox5.Visible = false;
                form05.Close ();
                formcheck5 = false;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox6.Checked == true)
            {
                this.checkBox9.Enabled = true;
                this.pictureBox6.Visible = true;
                Ss form06 = new Ss();
                form06.Show();
                formcheck6 = true;
            }
            else
            {
                this.checkBox9.Enabled = false;
                this.pictureBox6.Visible = false;
                form06.Close ();
                formcheck6 = false;
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            CreateFilePath cfpath = new CreateFilePath();
            cfpath.Show();
        }

        private void newFileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void aboutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            About formabout = new About();
            formabout.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            SaveFileDialog sf = new SaveFileDialog();
            sf.FileName = "flexConfig20";
            sf.Filter = "dat file(*.dat)|*.dat|txt files(*.txt)|*.txt";
            sf.AddExtension = true;
            sf.Title = "Save as";
            if (sf.ShowDialog() == DialogResult.OK)
            {
                FileStream fs = new FileStream(sf.FileName, FileMode.Create);
                StreamWriter sw = new StreamWriter(fs);
                sw.Write("FLEX_CONFIGURATION_FILE_V1.6\n");
                sw.Write("! Description: FLEX-SPAM model configuration file" + "\n");
                sw.Write("!========" + "\n");
                sw.Write("0         ! index describing model configuration (for ease of reference/documentation)" + "\n");
                sw.Write("'M0' ! nametag describing model configuration (eg, 'stdFLEX/powerAS', etc)" + "\n");
                sw.Write("!========" + "\n");
                sw.Write("FLEX RESERVOIR STATUS AND CONSTITUTIVE RELATIONSHIPS" + "\n");


                if (Form1.formcheck2 == false)
                {
                    sw.Write(".false. ! enableWR" + "\n");

                }
                else
                {
                    sw.Write(".true. ! enableWR" + "\n");
                    reservoirs = reservoirs + 1;
                }

                if (Form1.formcheck1 == false)
                {
                    sw.Write(".false.  ! enableIR    ! UR-A-ID: supported= 0,1,2,3,10,11,20,21,22,30,31,32" + "\n");
                }
                else
                {
                    sw.Write(".true.  ! enableIR    ! UR-A-ID: supported= 0,1,2,3,10,11,20,21,22,30,31,32" + "\n");
                    reservoirs = reservoirs + 1;
                }

                if (Form1.formcheck4 == false)
                {
                    sw.Write(".false.  ! enableRR    ! UR-B-ID: supported= 0,1 (more options easy to add)" + "\n");
                }
                else
                {
                    sw.Write(".true.  ! enableRR    ! UR-B-ID: supported= 0,1 (more options easy to add)" + "\n");
                    reservoirs = reservoirs + 1;
                }

                if (Form1.formcheck3 == false)
                {
                    sw.Write(".false.  ! enableUR     ! " + "\n");
                }
                else
                {
                    sw.Write(".true.  ! enableUR     ! " + "\n");
                    reservoirs = reservoirs + 1;
                }


                if (Form1.formcheck5 == false)
                {
                    sw.Write(".false.  ! enableFR    ! UR-E-ID: supported= 0,1,2,3,20,21,22,30,31,32" + "\n");

                }
                else
                {
                    sw.Write(".true.  ! enableFR    ! UR-E-ID: supported= 0,1,2,3,20,21,22,30,31,32" + "\n");
                    reservoirs = reservoirs + 1;
                }

                if (Form1.formcheck6 == false)
                {
                    sw.Write(".false.  ! enableSR    ! UR-D-ID: supported= 0" + "\n");

                }
                else
                {
                    sw.Write(".true.  ! enableSR    ! UR-D-ID: supported= 0" + "\n");
                    reservoirs = reservoirs + 1;
                }

                sw.Write(Form1.URFunA + "," + Form1.URFunB + "," + Form1.URFunE + "," + Form1.URFunD + "\n");
                sw.Write(Form1.EIR + "," + Form1.IRsmooth + "\n");
                sw.Write(Convert.ToString(Form1.FSFun) + "\n");
                sw.Write("-1           ! SuperFast LAGsmthID (Lag function smoothing)" + "\n");
                sw.Write("1           ! Fast LAGsmthID (Lag function smoothing)" + "\n");
                sw.Write("-1           ! Slow LAGsmthID: -1=original, 0=quadrature, 1=midpoint, 2=trapezoidal" + "\n");
                sw.Write("!========" + "\n");
                sw.Write("POSSIBILITY OF SUBSTITUTING FR TO FS" + "\n");
                sw.Write(".true.  ! use FS instead of FR if FR is enabled: Uses then parameters km,kp,ksmt,ediv insead of kf and alfa." + "\n");
                sw.Write("!========" + "\n");
                sw.Write("FLEX NUMERICS" + "\n");
                sw.Write("1       ! numerical solver for interception reservoir (0=odeint, 1=fixed-spm-implicit, 2=bounded EE, -1=simple-threshold, -2=algebraic-statique)" + "\n");
                sw.Write("3       ! numerical solver for simple reservoirs (0=odeint, 3=fixed-liebre-implicit, 2=bounded EE)" + "\n");
                sw.Write("1       ! numerical solver for UR zone (0=odeint, 1=fixed-spm-implicit, 2=bounded EE)" + "\n");
                sw.Write("!========" + "\n");
                sw.Write("FLEX CONFIGURATION INFORMATION" + "\n");
                if (Form1.Imaxcheck == true)
                    Form1.activePar += 1;
                if (Form1.IRsmthcheck == true)
                    Form1.activePar += 1;
                if (Form1.EFSsmcheck == true)
                    Form1.activePar += 1;
                if (Form1.Kfcheck == true)
                    Form1.activePar += 1;
                if (Form1.alfaFcheck == true)
                    Form1.activePar += 1;
                if (Form1.Kmcheck == true)
                    Form1.activePar += 1;
                if (Form1.Kpcheck == true)
                    Form1.activePar += 1;
                if (Form1.Sfbcheck == true)
                    Form1.activePar += 1;
                if (Form1.Ksmtcheck == true)
                    Form1.activePar += 1;
                if (Form1.ETparcheck == true)
                    Form1.activePar += 1;
                if (Form1.Sumaxcheck == true)
                    Form1.activePar += 1;
                if (Form1.Pmxcheck == true)
                    Form1.activePar += 1;
                if (Form1.Betacheck == true)
                    Form1.activePar += 1;
                if (Form1.Centercheck == true)
                    Form1.activePar += 1;
                if (Form1.T0check == true)
                    Form1.activePar += 1;
                if (Form1.T0smthcheck == true)
                    Form1.activePar += 1;
                if (Form1.wCorrcheck == true)
                    Form1.activePar += 1;
                if (Form1.Tmcheck == true)
                    Form1.activePar += 1;
                if (Form1.Tmsmthcheck == true)
                    Form1.activePar += 1;
                if (Form1.Kwcheck == true)
                    Form1.activePar += 1;
                if (Form1.Swsmthcheck == true)
                    Form1.activePar += 1;
                if (Form1.Krcheck == true)
                    Form1.activePar += 1;
                if (Form1.Kscheck == true)
                    Form1.activePar += 1;
                if (Form1.alfaScheck == true)
                    Form1.activePar += 1;

                Form1.activePar += 8;
                Form1.deadPar = 32 - Form1.activePar;

                sw.Write(Form1.activePar + "       " + "! number of active parameters" + "\n");
                sw.Write("0    ! number of fixed parameters" + "\n");
                sw.Write(Form1.deadPar + "       " + "! number of dead parameters" + "\n");
                sw.Write("5    ! number of reservoir states" + "\n");
                sw.Write(Convert.ToString(Form1.ConvolutionNumLR) + "\n");
                sw.Write(Convert.ToString(Form1.ConvolutionNumLF) + "\n");
                sw.Write(Convert.ToString(Form1.ConvolutionNumLS) + "\n");
                sw.Write("!========" + "\n");
                sw.Write("ACTIVE_PARAMETER_INFO (parameters visible to BATEA)" + "\n");

                sw.Write("parName           parDef            parLo         parHi      parScal     parSD         parTran   parFit    Comment" + "\n");
                sw.Write("\"rMult,- \"" + "    " + Form1.rMult01 + "    " + Form1.rMult02 + "    " + Form1.rMult03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.rMult04 + "    " + Form1.rMult05 + "    " + "(cannot be dead) Rainfall multiplication factor" + "\n");
                sw.Write("\"eMult,- \"" + "    " + Form1.eMult01 + "   " + Form1.eMult02 + "   " + Form1.eMult03 + "   " + "10.0" + "   " + "-9999.9" + "   " + Form1.eMult04 + "   " + Form1.eMult05 + "(cannot be dead) Multiplication factor for evaporation" + "\n");

                if (Form1.T0smthcheck == true)
                {
                    sw.Write("\"T0smth,-\"" + "    " + Form1.T0smth01 + "    " + Form1.T0smth02 + "    " + Form1.T0smth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.T0smth04 + "    " + Form1.T0smth05 + "    " + "Sw" + "\n");
                }
                if (Form1.Tmsmthcheck == true)
                {
                    sw.Write("\"Tmsmth,-\"" + "    " + Form1.Tmsmth01 + "    " + Form1.Tmsmth02 + "    " + Form1.Tmsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tmsmth04 + "    " + Form1.Tmsmth05 + "    " + "Sw" + "\n");
                }
                if (Form1.Swsmthcheck == true)
                {
                    sw.Write("\"Swsmth,-\"" + "    " + Form1.Swsmth01 + "    " + Form1.Swsmth02 + "    " + Form1.Swsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Swsmth04 + "    " + Form1.Swsmth05 + "    " + "Sw" + "\n");
                }
                if (Form1.Kwcheck == true)
                {
                    sw.Write("\"Kw,mm/ct\"" + "    " + Form1.Kw01 + "    " + Form1.Kw02 + "    " + Form1.Kw03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kw04 + "    " + Form1.Kw05 + "    " + "Sw" + "\n");
                }
                if (Form1.wCorrcheck == true)
                {
                    sw.Write("\"wCorr,- \"" + "    " + Form1.wCorr01 + "    " + Form1.wCorr02 + "    " + Form1.wCorr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.wCorr04 + "    " + Form1.wCorr05 + "    " + "Sw" + "\n");
                }
                if (Form1.Tmcheck == true)
                {
                    sw.Write("\"Tm, C   \"" + "    " + Form1.Tm01 + "    " + Form1.Tm02 + "    " + Form1.Tm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw" + "\n");
                }
                if (Form1.T0check == true)
                {
                    sw.Write("\"T0, C   \"" + "    " + Form1.T001 + "    " + Form1.T002 + "    " + Form1.T003 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw" + "\n");
                }

                if (Form1.Imaxcheck == true)
                {
                    sw.Write("\"Imax, mm\"" + "    " + Form1.Imax01 + "    " + Form1.Imax02 + "    " + Form1.Imax03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Imax04 + "    " + Form1.Imax05 + "    " + "Si" + "\n");
                }
                if (Form1.IRsmthcheck == true)
                {
                    sw.Write("\"IRsmth,-\"" + "    " + Form1.IRsmth01 + "    " + Form1.IRsmth02 + "    " + Form1.IRsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.IRsmth04 + "    " + Form1.IRsmth05 + "    " + "Si" + "\n");
                }
                if (Form1.ETparcheck == true)
                {
                    sw.Write("\"ETpar, -\"" + "    " + Form1.ETpar01 + "    " + Form1.ETpar02 + "    " + Form1.ETpar03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.ETpar04 + "    " + Form1.ETpar05 + "    " + "Su" + "\n");
                }
                if (Form1.Sumaxcheck == true)
                {
                    sw.Write("\"Sumax,mm\"" + "    " + Form1.Sumax01 + "    " + Form1.Sumax02 + "    " + Form1.Sumax03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Sumax04 + "    " + Form1.Sumax05 + "    " + "Su" + "\n");
                }
                if (Form1.Betacheck == true)
                {

                    sw.Write("\"Beta, - \"" + "    " + Form1.Beta01 + "    " + Form1.Beta02 + "    " + Form1.Beta03 + "    " + "10.0" + "    " + "-9999.9" + "   " + Form1.Beta04 + "  " + Form1.Beta05 + " " + "Su  (logistic & quadroid) Beta->0 gives stronger step-threshold in UR A(S) function" + "\n");
                }
                if (Form1.Pmxcheck == true)
                {
                    sw.Write("\"Pmx,mm/t\"" + "    " + Form1.Pmx01 + "    " + Form1.Pmx02 + "    " + Form1.Pmx03 + "    " + "10.0" + "    " + "-9999.0" + "    " + Form1.Pmx04 + "    " + Form1.Pmx05 + "       " + "Su" + "\n");
                }
                if (Form1.Centercheck == true)
                {
                    sw.Write("\"Center,-\"" + "    " + Form1.Center01 + "    " + Form1.Center02 + "    " + Form1.Center03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Center04 + "    " + Form1.Center05 + "    " + "Su" + "\n");
                }

                sw.Write("\"Peakf, t\"" + "    " + Form1.Peakf01 + "    " + Form1.Peakf02 + "    " + Form1.Peakf03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Peakf04 + "    " + Form1.Peakf05 + "    " + "Sf (cannot be dead) when LAGsmthID=1, nStateConv>peakF[hi] to avoid chopping recession of lag function" + "\n");

                if (Form1.FSFun == 23)
                {
                    if (Form1.EFSsmcheck == true)
                    {
                        sw.Write("\"EFSsm,mm\"" + "    " + Form1.EFSsm01 + "    " + Form1.EFSsm02 + "    " + Form1.EFSsm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.EFSsm04 + "    " + Form1.EFSsm05 + "    " + "Sf Smoothing factor for evaporation (only FS)" + "\n");
                    }
                    if (Form1.Ksmtcheck == true)
                    {
                        sw.Write("\"Ksmt,1/t\"" + "    " + Form1.Ksmt01 + "    " + Form1.Ksmt02 + "    " + Form1.Ksmt03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ksmt04 + "    " + Form1.Ksmt05 + "    " + "Sf" + "\n");
                    }
                    if (Form1.Kmcheck == true)
                    {
                        sw.Write("\"Km, 1/t \"" + "    " + Form1.Km01 + "    " + Form1.Km02 + "    " + Form1.Km03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Km04 + "    " + Form1.Km05 + "    " + "Sf" + "\n");
                    }
                    if (Form1.Kpcheck == true)
                    {
                        sw.Write("\"Kp, 1/t \"" + "    " + Form1.Kp01 + "    " + Form1.Kp02 + "    " + Form1.Kp03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kp04 + "    " + Form1.Kp05 + "    " + "Sf" + "\n");
                    }
                    if (Form1.Sfbcheck == true)
                    {
                        sw.Write("\"Sfb, mm \"" + "    " + Form1.Sfb01 + "    " + Form1.Sfb02 + "    " + Form1.Sfb03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Sfb04 + "    " + Form1.Sfb05 + "    " + "Sf" + "\n");
                    }
                }
                if (Form1.FSFun == 2)
                {
                    if (Form1.Kfcheck == true)
                    {
                        sw.Write("\"Kf, 1/t \"" + "    " + Form1.Kf01 + "  " + Form1.Kf02 + "  " + Form1.Kf03 + "  " + "10.0" + "  " + "-9999.9" + "   " + Form1.Kf04 + "  " + Form1.Kf05 + "       " + "Sf" + "\n");
                    }
                    if (Form1.alfaFcheck == true)
                    {
                        sw.Write("\"alfaF,- \"" + "    " + Form1.alfaF01 + "  " + Form1.alfaF02 + "  " + Form1.alfaF03 + "  " + "10.0" + "  " + "-9999.9" + "  " + Form1.alfaF04 + "  " + Form1.alfaF05 + "  " + "Sf" + "\n");
                    }
                }

                sw.Write("\"D, -    \"" + "    " + Form1.D01 + "    " + Form1.D02 + "    " + Form1.D03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.D04 + "    " + Form1.D05 + "    " + "(cannot be dead) D->1 diverts input from Fast convolution store to Slow convolution store" + "\n");
                sw.Write("\"Fr, -   \"" + "    " + Form1.Fr01 + "    " + Form1.Fr02 + "    " + Form1.Fr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Fr04 + "    " + Form1.Fr05 + "       " + "Su" + "\n");

                sw.Write("\"Peakr, t\"" + "    " + Form1.Peakr01 + "    " + Form1.Peakr02 + "    " + Form1.Peakr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Peakr04 + "    " + Form1.Peakr05 + "    " + " (cannot be dead) when LAGsmthID=1, nStateConv>peakF[hi] to avoid chopping recession of lag function" + "\n");
                if (Form1.Krcheck == true)
                {
                    sw.Write("\"Kr,1/t  \"" + "    " + Form1.Kr01 + "    " + Form1.Kr02 + "    " + Form1.Kr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kr04 + "    " + Form1.Kr05 + "    " + "Sr" + "\n");
                }
                sw.Write("\"Gam,mm/t\"" + "    " + Form1.Gam01 + "    " + Form1.Gam02 + "    " + Form1.Gam03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Gam04 + "    " + Form1.Gam05 + "\n");
                sw.Write("\"Peaks, t\"" + "    " + Form1.Peaks01 + "    " + Form1.Peaks02 + "    " + Form1.Peaks03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Peaks04 + "    " + Form1.Peaks05 + "\n");

                if (Form1.Kscheck == true)
                {
                    sw.Write("\"Ks, 1/t \"" + "    " + Form1.Ks01 + "    " + Form1.Ks02 + "    " + Form1.Ks03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ks04 + "    " + Form1.Ks05 + "    " + "Ss" + "\n");
                }
                if (Form1.alfaScheck == true)
                {
                    sw.Write("\"alfaS,- \"" + "    " + Form1.alfaS01 + "    " + Form1.alfaS02 + "    " + Form1.alfaS03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.alfaS04 + "    " + Form1.alfaS05 + "    " + "Ss" + "\n");
                }

                sw.Write("!========" + "\n");
                sw.Write("FIXED_PARAMETER_INFO (parameters that exist but are fixed and invisible to BATEA)" + "\n");
                sw.Write("!========" + "\n");
                sw.Write("MORTO_PARAMETER_INFO (parameters that dont exist for this configuration)" + "\n");

                if (Form1.Imaxcheck == false)
                {
                    sw.Write("\"Imax, mm\"" + "    " + Form1.Imax01 + "    " + Form1.Imax02 + "    " + Form1.Imax03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Imax04 + "    " + Form1.Imax05 + "    " + "Si" + "\n");
                }
                if (Form1.IRsmthcheck == false)
                {
                    sw.Write("\"IRsmth,-\"" + "    " + Form1.IRsmth01 + "    " + Form1.IRsmth02 + "    " + Form1.IRsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.IRsmth04 + "    " + Form1.IRsmth05 + "    " + "Si" + "\n");
                }

                if (Form1.Centercheck == false)
                {
                    sw.Write("\"Center,-\"" + "    " + Form1.Center01 + "    " + Form1.Center02 + "    " + Form1.Center03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Center04 + "    " + Form1.Center05 + "    " + "Su" + "\n");
                }

                if (Form1.Sumaxcheck == false)
                {
                    sw.Write("\"Sumax,mm\"" + "    " + Form1.Sumax01 + "    " + Form1.Sumax02 + "    " + Form1.Sumax03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Sumax04 + "    " + Form1.Sumax05 + "    " + "Su" + "\n");
                }

                if (Form1.Betacheck == false)
                {

                    sw.Write("\"Beta, - \"" + "    " + Form1.Beta01 + "    " + Form1.Beta02 + "    " + Form1.Beta03 + "    " + "10.0" + "    " + "-9999.9" + "   " + Form1.Beta04 + "  " + Form1.Beta05 + " " + "Su  (logistic & quadroid) Beta->0 gives stronger step-threshold in UR A(S) function" + "\n");
                }
                if (Form1.Kscheck == false)
                {
                    sw.Write("\"Ks, 1/t \"" + "    " + Form1.Ks01 + "    " + Form1.Ks02 + "    " + Form1.Ks03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ks04 + "    " + Form1.Ks05 + "    " + "Ss" + "\n");
                }
                if (Form1.alfaScheck == false)
                {
                    sw.Write("\"alfaS,- \"" + "    " + Form1.alfaS01 + "    " + Form1.alfaS02 + "    " + Form1.alfaS03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.alfaS04 + "    " + Form1.alfaS05 + "    " + "Ss" + "\n");
                }
                if (Form1.T0smthcheck == false)
                {
                    sw.Write("\"T0smth,-\"" + "    " + Form1.T0smth01 + "    " + Form1.T0smth02 + "    " + Form1.T0smth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.T0smth04 + "    " + Form1.T0smth05 + "    " + "Sw" + "\n");
                }
                if (Form1.Tmsmthcheck == false)
                {
                    sw.Write("\"Tmsmth,-\"" + "    " + Form1.Tmsmth01 + "    " + Form1.Tmsmth02 + "    " + Form1.Tmsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tmsmth04 + "    " + Form1.Tmsmth05 + "    " + "Sw" + "\n");
                }
                if (Form1.Swsmthcheck == false)
                {
                    sw.Write("\"Swsmth,-\"" + "    " + Form1.Swsmth01 + "    " + Form1.Swsmth02 + "    " + Form1.Swsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Swsmth04 + "    " + Form1.Swsmth05 + "    " + "Sw" + "\n");
                }
                if (Form1.Kwcheck == false)
                {
                    sw.Write("\"Kw,mm/ct\"" + "    " + Form1.Kw01 + "    " + Form1.Kw02 + "    " + Form1.Kw03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kw04 + "    " + Form1.Kw05 + "    " + "Sw" + "\n");
                }
                if (Form1.wCorrcheck == false)
                {
                    sw.Write("\"wCorr,- \"" + "    " + Form1.wCorr01 + "    " + Form1.wCorr02 + "    " + Form1.wCorr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.wCorr04 + "    " + Form1.wCorr05 + "    " + "Sw" + "\n");
                }
                if (Form1.Tmcheck == false)
                {
                    sw.Write("\"Tm, C   \"" + "    " + Form1.Tm01 + "    " + Form1.Tm02 + "    " + Form1.Tm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw" + "\n");
                }
                if (Form1.T0check == false)
                {
                    sw.Write("\"T0, C   \"" + "    " + Form1.T001 + "    " + Form1.T002 + "    " + Form1.T003 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw" + "\n");
                }
                if (Form1.Krcheck == false)
                {
                    sw.Write("\"Kr,1/t  \"" + "    " + Form1.Kr01 + "    " + Form1.Kr02 + "    " + Form1.Kr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kr04 + "    " + Form1.Kr05 + "    " + "Sr" + "\n");
                }
                if (Form1.FSFun == 2)
                {

                    sw.Write("\"EFSsm,mm\"" + "    " + Form1.EFSsm01 + "    " + Form1.EFSsm02 + "    " + Form1.EFSsm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.EFSsm04 + "    " + Form1.EFSsm05 + "    " + "Sf Smoothing factor for evaporation (only FS)" + "\n");
                    sw.Write("\"Ksmt,1/t\"" + "    " + Form1.Ksmt01 + "    " + Form1.Ksmt02 + "    " + Form1.Ksmt03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ksmt04 + "    " + Form1.Ksmt05 + "    " + "Sf" + "\n");
                    sw.Write("\"Km, 1/t \"" + "    " + Form1.Km01 + "    " + Form1.Km02 + "    " + Form1.Km03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Km04 + "    " + Form1.Km05 + "    " + "Sf" + "\n");
                    sw.Write("\"Kp, 1/t \"" + "    " + Form1.Kp01 + "    " + Form1.Kp02 + "    " + Form1.Kp03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kp04 + "    " + Form1.Kp05 + "    " + "Sf" + "\n");
                    sw.Write("\"Sfb, mm \"" + "    " + Form1.Sfb01 + "    " + Form1.Sfb02 + "    " + Form1.Sfb03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Sfb04 + "    " + Form1.Sfb05 + "    " + "Sf" + "\n");
                }
                else
                {
                    sw.Write("\"Kf, 1/t \"" + "    " + Form1.Kf01 + "  " + Form1.Kf02 + "  " + Form1.Kf03 + "  " + "10.0" + "  " + "-9999.9" + "   " + Form1.Kf04 + "  " + Form1.Kf05 + "       " + "Sf" + "\n");
                    sw.Write("\"alfaF,- \"" + "    " + Form1.alfaF01 + "  " + Form1.alfaF02 + "  " + Form1.alfaF03 + "  " + "10.0" + "  " + "-9999.9" + "  " + Form1.alfaF04 + "  " + Form1.alfaF05 + "  " + "Sf" + "\n");
                }



                sw.Write("!========                                     " + "\n");
                sw.Write("STATE INFO" + "\n");
                sw.Write("stateName        stateDef         stateLo       stateHi    stateScal  " + "\n");
                sw.Write("\"Qstrm\"" + "           0.0               0.0          1.e4         10.0" + "\n");
                sw.Write("\"Qpcor\"" + "           0.0               0.0          1.e4         10.0" + "\n");
                if (Form1.formcheck5 == true)
                {
                    sw.Write("\"Sf,mm\"" + "      " + Form1.InitialSf + "        " + Form1.LowestSf + "      " + Form1.HighestSf + "      " + "10.0" + "\n");
                }
                if (Form1.formcheck1 == true)
                {
                    sw.Write("\"Si,mm\"" + "       " + Form1.InitialSi + "     " + Form1.LowestSi + "      " + Form1.HighestSi + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck4 == true)
                {
                    sw.Write("\"Sr,mm\"" + "       " + Form1.InitialSr + "     " + Form1.LowestSr + "      " + Form1.HighestSr + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck6 == true)
                {
                    sw.Write("\"Ss,mm\"" + "       " + Form1.InitialSs + "     " + Form1.LowestSs + "      " + Form1.HighestSs + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck3 == true)
                {
                    sw.Write("\"Su,mm\"" + "       " + Form1.InitialSu + "     " + Form1.LowestSu + "      " + Form1.HighestSu + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck2 == true)
                {
                    sw.Write("\"Sw,mm\"" + "       " + Form1.InitialSw + "     " + Form1.LowestSw + "      " + Form1.HighestSw + "     " + "10.0" + "\n");
                }

                //sw.Write("");

                if (Form1.formcheck5 == false)
                {
                    sw.Write("\"Sf,mm\"" + "      " + Form1.InitialSf + "        " + Form1.LowestSf + "      " + Form1.HighestSf + "      " + "10.0" + "\n");
                }
                if (Form1.formcheck1 == false)
                {
                    sw.Write("\"Si,mm\"" + "       " + Form1.InitialSi + "     " + Form1.LowestSi + "      " + Form1.HighestSi + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck4 == false)
                {
                    sw.Write("\"Sr,mm\"" + "       " + Form1.InitialSr + "     " + Form1.LowestSr + "      " + Form1.HighestSr + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck6 == false)
                {
                    sw.Write("\"Ss,mm\"" + "       " + Form1.InitialSs + "     " + Form1.LowestSs + "      " + Form1.HighestSs + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck3 == false)
                {
                    sw.Write("\"Su,mm\"" + "       " + Form1.InitialSu + "     " + Form1.LowestSu + "      " + Form1.HighestSu + "     " + "10.0" + "\n");
                }
                if (Form1.formcheck2 == false)
                {
                    sw.Write("\"Sw,mm\"" + "       " + Form1.InitialSw + "     " + Form1.LowestSw + "      " + Form1.HighestSw + "     " + "10.0" );
                }

                sw.Write(""+"\n");
                sw.Close();
                fs.Close();
            }
        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox7.Checked==true )
            {
                LR form07 = new LR();
                form07.Show();
                this.pictureBox16.Visible = false;
            }
            else
            {
                this.pictureBox16.Visible = true;
                form07.Close ();
            }
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox8.Checked == true)
            {
                LF form08 = new LF();
                form08.Show();
                this.pictureBox17.Visible = false;
            }
            else
            {
                form08.Close ();
                this.pictureBox17.Visible = true;
            }
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
//            LS form09 = new LS();
            if (this.checkBox9.Checked == true)
            {
                LS form09 = new LS();   
                form09.Show();
                this.pictureBox18.Visible = false;
            }
            else
            {
                form09.Close ();
                this.pictureBox18.Visible = true;
            }
        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox10.Checked == true)
            {
                CR form10 = new CR();
                form10.Show();
                this.pictureBox20.Visible = true;
            }
            else
            {
                form10.Close ();
                this.pictureBox20.Visible = false;
            }
        }

        private void checkBox11_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox11.Checked == true)
            {
                CS form11 = new CS();
                form11.Show();
                this.pictureBox21.Visible = true;
            }
            else
            {
                form11.Close ();
                this.pictureBox21.Visible = false;
            }
        }

        private void checkBox12_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox12.Checked == true)
            {
                MP form12 = new MP();
                form12.Show();
                this.pictureBox14.Visible = true;
            }
            else
            {
                form12.Close ();
                this.pictureBox14.Visible = false;
            }
        }

        private void checkBox13_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox13.Checked == true)
            {
                ME form13 = new ME();
                form13.Show();
                this.pictureBox15.Visible = true;
            }
            else
            {
                form13.Close ();
                this.pictureBox15.Visible = false;
            }
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            
          }

        private void checkBox14_CheckedChanged(object sender, EventArgs e)
        {
            if (this.checkBox14.Checked == true)
            {
                this.pictureBox19.Visible = true;
            }
            else
            {
                this.pictureBox19.Visible = false;
            } 
        }

       

    }
}
