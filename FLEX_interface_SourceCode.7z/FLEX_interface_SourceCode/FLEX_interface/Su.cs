﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface

{
    public partial class Su : Form
    {
        public Su()
        {
            InitializeComponent();
        }

        double Epar01Val;
        double Epar02Val;
        double Epar03Val;
        double Sumax01Val;
        double Sumax02Val;
        double Sumax03Val;
        double Pmax01Val;
        double Pmax02Val;
        double Pmax03Val;
        double Beta01Val;
        double Beta02Val;
        double Beta03Val;
        double Center01Val;
        double Center02Val;
        double Center03Val;

        double SUInitialVal;
        double SULowVal;
        double SUHighVal;

        private void Su_Load(object sender, EventArgs e)
        {
            //textBox1.Enabled = false;
            //textBox2.Enabled = false;
            //textBox3.Enabled = false;
            //textBox4.Enabled = false;
            //textBox5.Enabled = false;
            
            //textBox11.Enabled = false;
            //textBox12.Enabled = false;
            //textBox13.Enabled = false;
            //textBox14.Enabled = false;
            //textBox15.Enabled = false;
            
            //textBox21.Enabled = false;
            //textBox22.Enabled = false;
            //textBox23.Enabled = false;
            //textBox24.Enabled = false;
            //textBox25.Enabled = false;
            
            //textBox31.Enabled = false;
            //textBox32.Enabled = false;
            //textBox33.Enabled = false;
            //textBox34.Enabled = false;
            //textBox35.Enabled = false;
            //textBox36.Enabled = false;
            //textBox37.Enabled = false;
            //textBox38.Enabled = false;
            //textBox39.Enabled = false;
            //textBox40.Enabled = false;

            textBox1.Text = "1.e-2";
            textBox2.Text = "1.e-2";
            textBox3.Text = "10.0";
            textBox4.Text = "1";
            textBox5.Text = "F";

            textBox11.Text = "200.0";
            textBox12.Text = "0.1";
            textBox13.Text = "1.e4";
            textBox14.Text = "1";
            textBox15.Text = "F";

            textBox21.Text = "1.e-3";
            textBox22.Text = "1.e-6";
            textBox23.Text = "2.0";
            textBox24.Text = "0";
            textBox25.Text = "F";
 
            textBox31.Text = "0.02";
            textBox32.Text = "1.e-3";
            textBox33.Text = "10.0";
            textBox34.Text = "1";
            textBox35.Text = "T";
            textBox36.Text = "0.5";
            textBox37.Text = "0.1";
            textBox38.Text = "1.0";
            textBox39.Text = "0";
            textBox40.Text = "F";

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Enabled == true)
            { Form1.ETparcheck = true; }
            else
                Form1.ETparcheck = false;

            if (textBox11.Enabled == true)
                Form1.Sumaxcheck = true;
            else
                Form1.Sumaxcheck = false;

            if (textBox21.Enabled == true)
                Form1.Pmxcheck = true;
            else
                Form1.Pmxcheck = false;

            if (textBox31.Enabled == true)
                Form1.Betacheck = true;
            else
                Form1.Betacheck = false;

            if (textBox36.Enabled == true)
                Form1.Centercheck = true;
            else
                Form1.Centercheck = false;

            bool SUValue = true;
            bool SUParTran = true;
            bool SUParFit = true;
            bool SUScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Epar01Eva = science.Match(textBox1.Text);
            Match Epar02Eva = science.Match(textBox2.Text);
            Match Epar03Eva = science.Match(textBox3.Text);
            Match Sumax01Eva = science.Match(textBox11.Text);
            Match Sumax02Eva = science.Match(textBox12.Text);
            Match Sumax03Eva = science.Match(textBox13.Text);
            Match Pmax01Eva = science.Match(textBox21.Text);
            Match Pmax02Eva = science.Match(textBox22.Text);
            Match Pmax03Eva = science.Match(textBox23.Text);
            Match Beta01Eva = science.Match(textBox31.Text);
            Match Beta02Eva = science.Match(textBox32.Text);
            Match Beta03Eva = science.Match(textBox33.Text);
            Match Center01Eva = science.Match(textBox36.Text);
            Match Center02Eva = science.Match(textBox37.Text);
            Match Center03Eva = science.Match(textBox38.Text);

            Match SUInitEva = science.Match(textBox41.Text);
            Match SULowEva = science.Match(textBox42.Text);
            Match SUHighEva = science.Match(textBox43.Text);


            if (!Epar01Eva.Success || !Epar02Eva.Success || !Epar03Eva.Success
                || !Sumax01Eva.Success || !Sumax02Eva.Success || !Sumax03Eva.Success
                || !Pmax01Eva.Success || !Pmax02Eva.Success || !Pmax03Eva.Success
                || !Beta01Eva.Success || !Beta02Eva.Success || !Beta03Eva.Success
                || !Center01Eva.Success || !Center02Eva.Success || !Center03Eva.Success
                || !SUInitEva.Success || !SULowEva.Success || !SUHighEva.Success)
            {
                SUValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Epar01Val = Convert.ToDouble(textBox1.Text);
                Epar02Val = Convert.ToDouble(textBox2.Text);
                Epar03Val = Convert.ToDouble(textBox3.Text);
                Sumax01Val = Convert.ToDouble(textBox11.Text);
                Sumax02Val = Convert.ToDouble(textBox12.Text);
                Sumax03Val = Convert.ToDouble(textBox13.Text);
                Pmax01Val = Convert.ToDouble(textBox21.Text);
                Pmax02Val = Convert.ToDouble(textBox22.Text);
                Pmax03Val = Convert.ToDouble(textBox23.Text);
                Beta01Val = Convert.ToDouble(textBox31.Text);
                Beta02Val = Convert.ToDouble(textBox32.Text);
                Beta03Val = Convert.ToDouble(textBox33.Text);
                Center01Val = Convert.ToDouble(textBox36.Text);
                Center02Val = Convert.ToDouble(textBox37.Text);
                Center03Val = Convert.ToDouble(textBox38.Text);

                SUInitialVal = Convert.ToDouble(textBox41.Text);
                SULowVal = Convert.ToDouble(textBox42.Text);
                SUHighVal = Convert.ToDouble(textBox43.Text);
            }

            if ((Epar01Val < Epar02Val || Epar01Val > Epar03Val)
                || (Sumax01Val < Sumax02Val || Sumax01Val > Sumax03Val)
                || (Pmax01Val < Pmax02Val || Pmax01Val > Pmax03Val)
                || (Beta01Val < Beta02Val || Beta01Val > Beta03Val)
                || (Center01Val < Center02Val || Center01Val > Center03Val)
                || (SUInitialVal < SULowVal || SUInitialVal > SUHighVal))
            {
                SUScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if ((textBox4.Text != "0" && textBox4.Text != "1") || (textBox14.Text != "0" && textBox14.Text != "1")
                || (textBox24.Text != "0" && textBox24.Text != "1") || (textBox34.Text != "0" && textBox34.Text != "1")
                || (textBox39.Text != "0" && textBox39.Text != "1"))
            {
                SUParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if ((textBox5.Text != "t" && textBox5.Text != "T" && textBox5.Text != "F" && textBox5.Text != "f")
                || (textBox15.Text != "t" && textBox15.Text != "T" && textBox15.Text != "F" && textBox15.Text != "f")
                || (textBox25.Text != "t" && textBox25.Text != "T" && textBox25.Text != "F" && textBox25.Text != "f")
                || (textBox35.Text != "t" && textBox35.Text != "T" && textBox35.Text != "F" && textBox35.Text != "f")
                || (textBox40.Text != "t" && textBox40.Text != "T" && textBox40.Text != "F" && textBox40.Text != "f"))
            {
                SUParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (SUValue == true && SUParTran == true && SUParFit == true && SUScale == true)
            {

                Form1.ETpar01 = textBox1.Text;
                Form1.ETpar02 = textBox2.Text;
                Form1.ETpar03 = textBox3.Text;
                Form1.ETpar04 = textBox4.Text;
                Form1.ETpar05 = textBox5.Text;
                Form1.Sumax01 = textBox11.Text;
                Form1.Sumax02 = textBox12.Text;
                Form1.Sumax03 = textBox13.Text;
                Form1.Sumax04 = textBox14.Text;
                Form1.Sumax05 = textBox15.Text;

                Form1.Pmx01 = textBox21.Text;
                Form1.Pmx02 = textBox22.Text;
                Form1.Pmx03 = textBox23.Text;
                Form1.Pmx04 = textBox24.Text;
                Form1.Pmx05 = textBox25.Text;

                Form1.Beta01 = textBox31.Text;
                Form1.Beta02 = textBox32.Text;
                Form1.Beta03 = textBox33.Text;
                Form1.Beta04 = textBox34.Text;
                Form1.Beta05 = textBox35.Text;
                Form1.Center01 = textBox36.Text;
                Form1.Center02 = textBox37.Text;
                Form1.Center03 = textBox38.Text;
                Form1.Center04 = textBox39.Text;
                Form1.Center05 = textBox40.Text;

                this.Close();
            }



        }



        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void zeroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 0;
            this.pictureBox14.Visible = true;
            this.pictureBox3.Visible = false;
            this.pictureBox4.Visible = false;
            this.pictureBox5.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox7.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox15.Visible = false;
            this.textBox31.Enabled = false;
            this.textBox32.Enabled = false;
            this.textBox33.Enabled = false;
            this.textBox34.Enabled = false;
            this.textBox35.Enabled = false;
            this.textBox36.Enabled = false;
            this.textBox37.Enabled = false;
            this.textBox38.Enabled = false;
            this.textBox39.Enabled = false;
            this.textBox40.Enabled = false;
        }

        private void linearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 1;
            this.pictureBox15.Visible = true;
            this.pictureBox3.Visible = false;
            this.pictureBox4.Visible = false;
            this.pictureBox5.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox7.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox14.Visible = false;
            this.textBox31.Enabled = false;
            this.textBox32.Enabled = false;
            this.textBox33.Enabled = false;
            this.textBox34.Enabled = false;
            this.textBox35.Enabled = false;
            this.textBox36.Enabled = false;
            this.textBox37.Enabled = false;
            this.textBox38.Enabled = false;
            this.textBox39.Enabled = false;
            this.textBox40.Enabled = false;
        }

        private void fdToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 2;
            this.pictureBox3.Visible = true;
            this.pictureBox4.Visible = false;
            this.pictureBox5.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox7.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox14.Visible = false;
            this.pictureBox15.Visible = false;
            this.textBox31.Enabled = true;
            this.textBox32.Enabled = true;
            this.textBox33.Enabled = true;
            this.textBox34.Enabled = true;
            this.textBox35.Enabled = true;
            this.textBox36.Enabled = false;
            this.textBox37.Enabled = false;
            this.textBox38.Enabled = false;
            this.textBox39.Enabled = false;
            this.textBox40.Enabled = false;
        }

        private void refPowToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 3;
            this.pictureBox4.Visible = true;
            this.pictureBox3.Visible = false;
            this.pictureBox5.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox7.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox14.Visible = false;
            this.pictureBox15.Visible = false;
            this.textBox31.Enabled = true;
            this.textBox32.Enabled = true;
            this.textBox33.Enabled = true;
            this.textBox34.Enabled = true;
            this.textBox35.Enabled = true;
            this.textBox36.Enabled = false;
            this.textBox37.Enabled = false;
            this.textBox38.Enabled = false;
            this.textBox39.Enabled = false;
            this.textBox40.Enabled = false;
        }

        private void logisticToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 10;
            this.pictureBox8.Visible = true;
            this.pictureBox4.Visible = false;
            this.pictureBox5.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox3.Visible = false;
            this.pictureBox7.Visible = false;
            this.pictureBox14.Visible = false;
            this.pictureBox15.Visible = false;
            Form1.Centercheck = true;
            this.textBox31.Enabled = true;
            this.textBox32.Enabled = true;
            this.textBox33.Enabled = true;
            this.textBox34.Enabled = true;
            this.textBox35.Enabled = true;
            this.textBox36.Enabled = true;
            this.textBox37.Enabled = true;
            this.textBox38.Enabled = true;
            this.textBox39.Enabled = true;
            this.textBox40.Enabled = true;
        }


        private void tessierToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 30;
            this.pictureBox7.Visible = true;
            this.pictureBox3.Visible = false;
            this.pictureBox5.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox4.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox14.Visible = false;
            this.pictureBox15.Visible = false;
            this.textBox31.Enabled = true;
            this.textBox32.Enabled = true;
            this.textBox33.Enabled = true;
            this.textBox34.Enabled = true;
            this.textBox35.Enabled = true;
            this.textBox36.Enabled = false;
            this.textBox37.Enabled = false;
            this.textBox38.Enabled = false;
            this.textBox39.Enabled = false;
            this.textBox40.Enabled = false;
        }

        private void michMentesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 31;
            this.pictureBox5.Visible = true;
            this.pictureBox3.Visible = false;
            this.pictureBox4.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox7.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox14.Visible = false;
            this.pictureBox15.Visible = false;
            this.textBox31.Enabled = true;
            this.textBox32.Enabled = true;
            this.textBox33.Enabled = true;
            this.textBox34.Enabled = true;
            this.textBox35.Enabled = true;
            this.textBox36.Enabled = false;
            this.textBox37.Enabled = false;
            this.textBox38.Enabled = false;
            this.textBox39.Enabled = false;
            this.textBox40.Enabled = false;
        }

        private void zeroToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1.URFunB = 0;
            this.pictureBox17.Visible = true;
            this.pictureBox18.Visible = false;
            this.textBox21.Enabled = false;
            textBox22.Enabled = false;
            textBox23.Enabled = false;
            textBox24.Enabled = false;
            textBox25.Enabled = false;
        }

        private void linearToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1.URFunB = 1;
            this.pictureBox17.Visible = false;
            this.pictureBox18.Visible = true;
            this.textBox21.Enabled = true;
            textBox22.Enabled = true;
            textBox23.Enabled = true;
            textBox24.Enabled = true;
            textBox25.Enabled = true;
        }

        private void zeroToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form1.URFunE = 0;
            this.pictureBox19.Visible = true;
            this.pictureBox20.Visible = false;
            this.pictureBox9.Visible = false;
            this.pictureBox10.Visible = false;
            this.pictureBox11.Visible = false;
            this.pictureBox12.Visible = false;
            this.pictureBox13.Visible = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
        }

        private void linearToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form1.URFunE = 1;
            this.pictureBox19.Visible = false;
            this.pictureBox20.Visible = true;
            this.pictureBox9.Visible = false;
            this.pictureBox10.Visible = false;
            this.pictureBox11.Visible = false;
            this.pictureBox12.Visible = false;
            this.pictureBox13.Visible = false;
            textBox1.Enabled = false;
            textBox2.Enabled = false;
            textBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
        }

        private void powerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form1.URFunE = 2;
            this.pictureBox19.Visible = false;
            this.pictureBox20.Visible = false;
            this.pictureBox9.Visible = true;
            this.pictureBox10.Visible = false;
            this.pictureBox11.Visible = false;
            this.pictureBox12.Visible = false;
            this.pictureBox13.Visible = false;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
        }

        private void refPowToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1.URFunE = 3;
            this.pictureBox19.Visible = false;
            this.pictureBox20.Visible = false;
            this.pictureBox9.Visible = false;
            this.pictureBox10.Visible = true;
            this.pictureBox11.Visible = false;
            this.pictureBox12.Visible = false;
            this.pictureBox13.Visible = false;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
        }

        private void tessierToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1.URFunE = 30;
            this.pictureBox19.Visible = false;
            this.pictureBox20.Visible = false;
            this.pictureBox9.Visible = false;
            this.pictureBox10.Visible = false;
            this.pictureBox11.Visible = false;
            this.pictureBox12.Visible = false;
            this.pictureBox13.Visible = true;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
        }

        private void michMentesToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1.URFunE = 31;
            this.pictureBox19.Visible = false;
            this.pictureBox20.Visible = false;
            this.pictureBox9.Visible = false;
            this.pictureBox10.Visible = false;
            this.pictureBox11.Visible = true;
            this.pictureBox12.Visible = false;
            this.pictureBox13.Visible = false;
            textBox1.Enabled = true;
            textBox2.Enabled = true;
            textBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Form1.URFunA = 21;
            this.pictureBox5.Visible = true;
            this.pictureBox3.Visible = false;
            this.pictureBox4.Visible = false;
            this.pictureBox6.Visible = false;
            this.pictureBox7.Visible = false;
            this.pictureBox8.Visible = false;
            this.pictureBox14.Visible = false;
            this.pictureBox15.Visible = false;
        }

        private void constructiveFunctionForAToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            Form1.URFunE = 21;
            this.pictureBox19.Visible = false;
            this.pictureBox20.Visible = false;
            this.pictureBox9.Visible = false;
            this.pictureBox10.Visible = false;
            this.pictureBox11.Visible = false;
            this.pictureBox12.Visible = true;
            this.pictureBox13.Visible = false;
        }


       

    }
}
