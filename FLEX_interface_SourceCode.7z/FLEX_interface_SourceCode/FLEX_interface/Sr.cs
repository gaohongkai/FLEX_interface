﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class Sr : Form
    {
//        public Sr()
//        {
//            InitializeComponent();
//        }

        double Kf01Val;
        double Kf02Val;
        double Kf03Val;
        double Alfaf01Val;
        double Alfaf02Val;
        double Alfaf03Val;
        double Efsmth01Val;
        double Efsmth02Val;
        double Efsmth03Val;
        double Km01Val;
        double Km02Val;
        double Km03Val;
        double Kp01Val;
        double Kp02Val;
        double Kp03Val;
        double Sfb01Val;
        double Sfb02Val;
        double Sfb03Val;
        double Ksmth01Val;
        double Ksmth02Val;
        double Ksmth03Val;

        double SFInitialVal;
        double SFLowVal;
        double SFHighVal;

        private void button1_Click(object sender, EventArgs e)
        {

            bool SFValue = true;
            bool SFParTran = true;
            bool SFParFit = true;
            bool SFScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Kf01Eva = science.Match(textBox11.Text);
            Match Kf02Eva = science.Match(textBox12.Text);
            Match Kf03Eva = science.Match(textBox13.Text);
            Match Alfaf01Eva = science.Match(textBox16.Text);
            Match Alfaf02Eva = science.Match(textBox17.Text);
            Match Alfaf03Eva = science.Match(textBox18.Text);
            Match Efsmth01Eva = science.Match(textBox6.Text);
            Match Efsmth02Eva = science.Match(textBox7.Text);
            Match Efsmth03Eva = science.Match(textBox8.Text);
            Match Km01Eva = science.Match(textBox21.Text);
            Match Km02Eva = science.Match(textBox22.Text);
            Match Km03Eva = science.Match(textBox23.Text);
            Match Kp01Eva = science.Match(textBox26.Text);
            Match Kp02Eva = science.Match(textBox27.Text);
            Match Kp03Eva = science.Match(textBox28.Text);
            Match Sfb01Eva = science.Match(textBox31.Text);
            Match Sfb02Eva = science.Match(textBox32.Text);
            Match Sfb03Eva = science.Match(textBox33.Text);
            Match Ksmth01Eva = science.Match(textBox36.Text);
            Match Ksmth02Eva = science.Match(textBox37.Text);
            Match Ksmth03Eva = science.Match(textBox38.Text);

            Match SFInitEva = science.Match(textBox1.Text);
            Match SFLowEva = science.Match(textBox2.Text);
            Match SFHighEva = science.Match(textBox3.Text);


            if (!Kf01Eva.Success || !Kf02Eva.Success || !Kf03Eva.Success || !Alfaf01Eva.Success
                || !Alfaf02Eva.Success || !Alfaf03Eva.Success ||!Efsmth01Eva.Success ||!Efsmth02Eva.Success ||
                !Efsmth03Eva.Success ||!Km01Eva.Success ||!Km02Eva.Success ||!Km03Eva.Success ||!Kp01Eva.Success ||
                !Kp02Eva.Success ||!Kp03Eva.Success ||!Sfb01Eva.Success ||!Sfb02Eva.Success ||!Sfb03Eva.Success ||
                !Ksmth01Eva.Success ||!Ksmth02Eva.Success ||!Ksmth03Eva.Success 
                || !SFInitEva.Success || !SFLowEva.Success || !SFHighEva.Success)
            {
                SFValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Kf01Val = Convert.ToDouble(textBox11.Text);
                Kf02Val = Convert.ToDouble(textBox12.Text);
                Kf03Val = Convert.ToDouble(textBox13.Text);
                Alfaf01Val = Convert.ToDouble(textBox16.Text);
                Alfaf02Val = Convert.ToDouble(textBox17.Text);
                Alfaf03Val = Convert.ToDouble(textBox18.Text);
                Efsmth01Val = Convert.ToDouble(textBox6.Text);
                Efsmth02Val = Convert.ToDouble(textBox7.Text);
                Efsmth03Val = Convert.ToDouble(textBox8.Text);
                Km01Val=Convert .ToDouble (textBox21.Text);
                Km02Val=Convert.ToDouble(textBox22.Text);
                Km03Val=Convert .ToDouble (textBox23.Text);
                Kp01Val = Convert.ToDouble(textBox26.Text);
                Kp02Val = Convert.ToDouble(textBox27.Text);
                Kp03Val = Convert.ToDouble(textBox28.Text);
                Sfb01Val = Convert.ToDouble(textBox31.Text);
                Sfb02Val = Convert.ToDouble(textBox32.Text);
                Sfb03Val = Convert.ToDouble(textBox33.Text);
                Ksmth01Val = Convert.ToDouble(textBox36.Text);
                Ksmth02Val = Convert.ToDouble(textBox37.Text);
                Ksmth03Val = Convert.ToDouble(textBox38.Text);

                SFInitialVal = Convert.ToDouble(textBox1.Text);
                SFLowVal = Convert.ToDouble(textBox2.Text);
                SFHighVal = Convert.ToDouble(textBox3.Text);
            }

            if ((Kf01Val < Kf02Val || Kf01Val > Kf03Val) || (Alfaf01Val < Alfaf02Val || Alfaf01Val > Alfaf03Val)
                || (Efsmth01Val < Efsmth02Val || Efsmth01Val > Efsmth03Val) || (Km01Val < Km02Val || Km01Val > Km03Val)
                || (Kp01Val < Kp02Val || Kp01Val > Kp03Val) || (Sfb01Val < Sfb02Val || Sfb01Val > Sfb03Val)
                || (Ksmth01Val < Ksmth02Val || Ksmth01Val > Ksmth03Val) || (SFInitialVal < SFLowVal || SFInitialVal > SFHighVal))
            {
                SFScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if ((textBox14.Text != "0" && textBox14.Text != "1") || (textBox9.Text != "0" && textBox9.Text != "1") ||
                (textBox24.Text != "0" && textBox24.Text != "1") || (textBox19.Text != "0" && textBox19.Text != "1") ||
                (textBox34.Text != "0" && textBox34.Text != "1") || (textBox29.Text != "0" && textBox29.Text != "1") ||
                (textBox39.Text != "0" && textBox9.Text != "1"))
            {
                SFParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if ((textBox10.Text != "t" && textBox10.Text != "T" && textBox10.Text != "F" && textBox10.Text != "f") ||
                (textBox15.Text != "t" && textBox15.Text != "T" && textBox15.Text != "F" && textBox15.Text != "f") ||
                (textBox20.Text != "t" && textBox20.Text != "T" && textBox20.Text != "F" && textBox20.Text != "f") ||
                (textBox25.Text != "t" && textBox25.Text != "T" && textBox25.Text != "F" && textBox25.Text != "f") ||
                (textBox30.Text != "t" && textBox30.Text != "T" && textBox30.Text != "F" && textBox30.Text != "f") ||
                (textBox35.Text != "t" && textBox35.Text != "T" && textBox35.Text != "F" && textBox35.Text != "f") ||
                (textBox40.Text != "t" && textBox40.Text != "T" && textBox40.Text != "F" && textBox40.Text != "f"))
            {
                SFParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (SFValue == true && SFParTran == true && SFParFit == true && SFScale == true)
            {

                Form1.EFSsm01 = textBox6.Text;
                Form1.EFSsm02 = textBox7.Text;
                Form1.EFSsm03 = textBox8.Text;
                Form1.EFSsm04 = textBox9.Text;
                Form1.EFSsm05 = textBox10.Text;
                Form1.Kf01 = textBox11.Text;
                Form1.Kf02 = textBox12.Text;
                Form1.Kf03 = textBox13.Text;
                Form1.Kf04 = textBox14.Text;
                Form1.Kf05 = textBox15.Text;
                Form1.alfaF01 = textBox16.Text;
                Form1.alfaF02 = textBox17.Text;
                Form1.alfaF03 = textBox18.Text;
                Form1.alfaF04 = textBox19.Text;
                Form1.alfaF05 = textBox20.Text;
                Form1.Km01 = textBox21.Text;
                Form1.Km02 = textBox22.Text;
                Form1.Km03 = textBox23.Text;
                Form1.Km04 = textBox24.Text;
                Form1.Km05 = textBox25.Text;
                Form1.Kp01 = textBox26.Text;
                Form1.Kp02 = textBox27.Text;
                Form1.Kp03 = textBox28.Text;
                Form1.Kp04 = textBox29.Text;
                Form1.Kp05 = textBox30.Text;
                Form1.Sfb01 = textBox31.Text;
                Form1.Sfb02 = textBox32.Text;
                Form1.Sfb03 = textBox33.Text;
                Form1.Sfb04 = textBox34.Text;
                Form1.Sfb05 = textBox35.Text;
                Form1.Ksmt01 = textBox36.Text;
                Form1.Ksmt02 = textBox37.Text;
                Form1.Ksmt03 = textBox38.Text;
                Form1.Ksmt04 = textBox39.Text;
                Form1.Ksmt05 = textBox40.Text;

                Form1.InitialSf = textBox1.Text;
                Form1.LowestSf = textBox2.Text;
                Form1.HighestSf = textBox3.Text;

                Form1.EFSsmcheck = this.checkBox1.Checked;
                Form1.Kfcheck = this.checkBox2.Checked;
                Form1.alfaFcheck = this.checkBox3.Checked;
                Form1.Kmcheck = this.checkBox4.Checked;
                Form1.Kpcheck = this.checkBox5.Checked;
                Form1.Sfbcheck = this.checkBox6.Checked;
                Form1.Ksmtcheck = this.checkBox7.Checked;

                if (radioButton1.Checked == true)
                {
                    Form1.FSFun = 2;
                }
                else
                {
                    Form1.FSFun = 23;
                }

                this.Close();
            }


        }


 

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                textBox6.Enabled = false;
                textBox7.Enabled = false;
                textBox8.Enabled = false;
                textBox9.Enabled = false;
                textBox10.Enabled = false;
                Form1.EFSsmcheck = false;
            }
            else
            {
                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;
                textBox9.Enabled = true;
                textBox10.Enabled = true;
                Form1.EFSsmcheck = true;
            }
        }




        private void Sr_Load(object sender, EventArgs e)
        {

            textBox6.Text = "0.5";
            textBox7.Text = "0.01";
            textBox8.Text = "2.0";
            textBox9.Text = "1";
            textBox10.Text = "F";
            textBox11.Text = "0.01";
            textBox12.Text = "1.e-4";
            textBox13.Text = "10.0";
            textBox14.Text = "1";
            textBox15.Text = "T";
            textBox16.Text = "2.0";
            textBox17.Text = "0.1";
            textBox18.Text = "5.0";
            textBox19.Text = "1";
            textBox20.Text = "T";
            textBox21.Text = "1.e-5";
            textBox22.Text = "1.e-6";
            textBox23.Text = "1.e-3";
            textBox24.Text = "1";
            textBox25.Text = "T";
            textBox26.Text = "5.e-3";
            textBox27.Text = "1.e-3";
            textBox28.Text = "2.0";
            textBox29.Text = "1";
            textBox30.Text = "T";
            textBox31.Text = "60.0";
            textBox32.Text = "5.0";
            textBox33.Text = "100.0";
            textBox34.Text = "1";
            textBox35.Text = "T";
            textBox36.Text = "0.2";
            textBox37.Text = "0.01";
            textBox38.Text = "2.0";
            textBox39.Text = "1";
            textBox40.Text = "T";


            textBox6.Enabled = false;
            textBox7.Enabled = false;
            textBox8.Enabled = false;
            textBox9.Enabled = false;
            textBox10.Enabled = false;
            //textBox11.Enabled = true;
            //textBox12.Enabled = true;
            //textBox13.Enabled = true;
            //textBox14.Enabled = true;
            //textBox15.Enabled = true;
            //textBox16.Enabled = true;
            //textBox17.Enabled = true;
            //textBox18.Enabled = true;
            //textBox19.Enabled = true;
            //textBox20.Enabled = true;
            textBox21.Enabled = false;
            textBox22.Enabled = false;
            textBox23.Enabled = false;
            textBox24.Enabled = false;
            textBox25.Enabled = false;
            textBox26.Enabled = false;
            textBox27.Enabled = false;
            textBox28.Enabled = false;
            textBox29.Enabled = false;
            textBox30.Enabled = false;
            textBox31.Enabled = false;
            textBox32.Enabled = false;
            textBox33.Enabled = false;
            textBox34.Enabled = false;
            textBox35.Enabled = false;
            textBox36.Enabled = false;
            textBox37.Enabled = false;
            textBox38.Enabled = false;
            textBox39.Enabled = false;
            textBox40.Enabled = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == false)
            {
                textBox11.Enabled = false;
                textBox12.Enabled = false;
                textBox13.Enabled = false;
                textBox14.Enabled = false;
                textBox15.Enabled = false;
                Form1.Kfcheck = false;
            }
            else
            {
                textBox11.Enabled = true;
                textBox12.Enabled = true;
                textBox13.Enabled = true;
                textBox14.Enabled = true;
                textBox15.Enabled = true;
                Form1.Kfcheck = true;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == false)
            {
                textBox16.Enabled = false;
                textBox17.Enabled = false;
                textBox18.Enabled = false;
                textBox19.Enabled = false;
                textBox20.Enabled = false;
                Form1.alfaFcheck = false;
            }
            else
            {
                textBox16.Enabled = true;
                textBox17.Enabled = true;
                textBox18.Enabled = true;
                textBox19.Enabled = true;
                textBox20.Enabled = true;
                Form1.alfaFcheck = true;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == false)
            {
                textBox21.Enabled = false;
                textBox22.Enabled = false;
                textBox23.Enabled = false;
                textBox24.Enabled = false;
                textBox25.Enabled = false;
                Form1.Kmcheck = false;
            }
            else
            {
                textBox21.Enabled = true;
                textBox22.Enabled = true;
                textBox23.Enabled = true;
                textBox24.Enabled = true;
                textBox25.Enabled = true;
                Form1.Kmcheck = true;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == false)
            {
                textBox26.Enabled = false;
                textBox27.Enabled = false;
                textBox28.Enabled = false;
                textBox29.Enabled = false;
                textBox30.Enabled = false;
                Form1.Kpcheck = false;
            }
            else
            {
                textBox26.Enabled = true;
                textBox27.Enabled = true;
                textBox28.Enabled = true;
                textBox29.Enabled = true;
                textBox30.Enabled = true;
                Form1.Kpcheck = true;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == false)
            {
                textBox31.Enabled = false;
                textBox32.Enabled = false;
                textBox33.Enabled = false;
                textBox34.Enabled = false;
                textBox35.Enabled = false;
                Form1.Sfbcheck = false;
            }
            else
            {
                textBox31.Enabled = true;
                textBox32.Enabled = true;
                textBox33.Enabled = true;
                textBox34.Enabled = true;
                textBox35.Enabled = true;
                Form1.Sfbcheck = true;
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == false)
            {
                textBox36.Enabled = false;
                textBox37.Enabled = false;
                textBox38.Enabled = false;
                textBox39.Enabled = false;
                textBox40.Enabled = false;
                Form1.Ksmtcheck = false;
            }
            else
            {
                textBox36.Enabled = true;
                textBox37.Enabled = true;
                textBox38.Enabled = true;
                textBox39.Enabled = true;
                textBox40.Enabled = true;
                Form1.Ksmtcheck = true;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                checkBox2.Checked = true;
                checkBox3.Checked = true;
                checkBox1.Checked = false;
                checkBox4.Checked = false;
                checkBox5.Checked = false;
                checkBox6.Checked = false;
                checkBox7.Checked = false;
            }
            else
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                checkBox1.Checked = true;
                checkBox4.Checked = true;
                checkBox5.Checked = true;
                checkBox6.Checked = true;
                checkBox7.Checked = true;
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton2.Checked == true)
            {
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                textBox11.Enabled = false;
                textBox12.Enabled = false;
                textBox13.Enabled = false;
                textBox14.Enabled = false;
                textBox15.Enabled = false;
                textBox16.Enabled = false;
                textBox17.Enabled = false;
                textBox18.Enabled = false;
                textBox19.Enabled = false;
                textBox20.Enabled = false;

                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;
                textBox9.Enabled = true;
                textBox10.Enabled = true;
                textBox21.Enabled = true;
                textBox22.Enabled = true;
                textBox23.Enabled = true;
                textBox24.Enabled = true;
                textBox25.Enabled = true;
                textBox26.Enabled =true;
                textBox27.Enabled = true;
                textBox28.Enabled = true;
                textBox29.Enabled = true;
                textBox30.Enabled = true;
                textBox31.Enabled = true;
                textBox32.Enabled = true;
                textBox33.Enabled = true;
                textBox34.Enabled = true;
                textBox35.Enabled = true;
                textBox36.Enabled = true;
                textBox37.Enabled = true;
                textBox38.Enabled = true;
                textBox39.Enabled = true;
                textBox40.Enabled = true;
            }
        }
    }
}


