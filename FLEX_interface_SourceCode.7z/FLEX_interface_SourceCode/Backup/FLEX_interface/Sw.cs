﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class Sw : Form
    {
        double T001Val;
        double T002Val;
        double T003Val;
        double T0smth01Val;
        double T0smth02Val;
        double T0smth03Val;
        double Wcorr01Val;
        double Wcorr02Val;
        double Wcorr03Val;
        double Tm01Val;
        double Tm02Val;
        double Tm03Val;
        double Tmsmth01Val;
        double Tmsmth02Val;
        double Tmsmth03Val;
        double Kw01Val;
        double Kw02Val;
        double Kw03Val;
        double Swsmth01Val;
        double Swsmth02Val;
        double Swsmth03Val;
        double Sw01Val;
        double Sw02Val;
        double Sw03Val;

        public Sw()
        {
            InitializeComponent();
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            Form1.T0smth05 = textBox10.Text;
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            Form1.T0smth02 = textBox7.Text;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            bool SwValue = true;
            bool SwParTran = true;
            bool SwParFit = true;
            bool SwScale = true;

//            Regex f = new Regex(@"^\d+(\.\d+)?$");//float regular expression
//            Regex i = new Regex(@"^\d*$"); //int regular expression
            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match T001Eva = science.Match(textBox1.Text);
            Match T002Eva = science.Match(textBox2.Text);
            Match T003Eva = science.Match(textBox3.Text);
            Match T0smth01Eva = science.Match(textBox6.Text);
            Match T0smth02Eva = science.Match(textBox7.Text);
            Match T0smth03Eva = science.Match(textBox8.Text);
            Match Wcorr01Eva = science.Match(textBox11.Text);
            Match Wcorr02Eva = science.Match(textBox12.Text);
            Match Wcorr03Eva = science.Match(textBox13.Text);
            Match Tm01Eva = science.Match(textBox16.Text);
            Match Tm02Eva = science.Match(textBox17.Text);
            Match Tm03Eva = science.Match(textBox18.Text);
            Match Tmsmth01Eva = science.Match(textBox21.Text);
            Match Tmsmth02Eva = science.Match(textBox22.Text);
            Match Tmsmth03Eva = science.Match(textBox23.Text);
            Match Kw01Eva = science.Match(textBox26.Text);
            Match Kw02Eva = science.Match(textBox27.Text);
            Match Kw03Eva = science.Match(textBox28.Text);
            Match Swsmth01Eva = science.Match(textBox31.Text);
            Match Swsmth02Eva = science.Match(textBox32.Text);
            Match Swsmth03Eva = science.Match(textBox33.Text);
            Match SwInitEva = science.Match(textBox36.Text);
            Match SwLowEva = science.Match(textBox37.Text);
            Match SwHigEva = science.Match(textBox38.Text);


            if (!T001Eva.Success || !T002Eva.Success || !T003Eva.Success || !T0smth01Eva.Success || !T0smth02Eva.Success
                || !T0smth03Eva.Success || !Wcorr01Eva.Success || !Wcorr02Eva.Success || !Wcorr03Eva.Success || !Tm01Eva.Success
                || !Tm02Eva.Success || !Tm03Eva.Success || !Tmsmth01Eva.Success || !Tmsmth02Eva.Success || !Tmsmth03Eva.Success
                || !Kw01Eva.Success || !Kw02Eva.Success || !Kw03Eva.Success || !Swsmth01Eva.Success || !Swsmth02Eva.Success
            || !Swsmth03Eva.Success || !SwInitEva.Success || !SwLowEva.Success || !SwHigEva.Success)
            {
                SwValue = false;
                MessageBox.Show("Please input right number!");
            }
            else
            {
                 T001Val= Convert.ToDouble(textBox1.Text);
                T002Val = Convert.ToDouble(textBox2.Text);
                T003Val = Convert.ToDouble(textBox3.Text);
                T0smth01Val = Convert.ToDouble(textBox6.Text);
                T0smth02Val = Convert.ToDouble(textBox7.Text);
                T0smth03Val = Convert.ToDouble(textBox8.Text);
                Wcorr01Val = Convert.ToDouble(textBox11.Text);
                Wcorr02Val = Convert.ToDouble(textBox12.Text);
                Wcorr03Val = Convert.ToDouble(textBox13.Text);
                Tm01Val = Convert.ToDouble(textBox16.Text);
                Tm02Val = Convert.ToDouble(textBox17.Text);
                Tm03Val = Convert.ToDouble(textBox18.Text);
                Tmsmth01Val = Convert.ToDouble(textBox21.Text);
                Tmsmth02Val = Convert.ToDouble(textBox22.Text);
                Tmsmth03Val = Convert.ToDouble(textBox23.Text);
                Kw01Val = Convert.ToDouble(textBox26.Text);
                Kw02Val = Convert.ToDouble(textBox27.Text);
                Kw03Val = Convert.ToDouble(textBox28.Text);
                Swsmth01Val = Convert.ToDouble(textBox31.Text);
                Swsmth02Val = Convert.ToDouble(textBox32.Text);
                Swsmth03Val = Convert.ToDouble(textBox33.Text);
                Sw01Val = Convert.ToDouble(textBox36.Text);
                Sw02Val = Convert.ToDouble(textBox37.Text);
                Sw03Val = Convert.ToDouble(textBox38.Text);
            }

            if((textBox4.Text!="0" && textBox4.Text!="1") || (textBox9.Text!="0" && textBox9.Text!="1") ||(textBox14.Text!="0" && textBox14.Text!="1") 
                ||(textBox19.Text!="0" && textBox19.Text!="1") ||(textBox24.Text!="0" && textBox24.Text!="1") ||(textBox29.Text!="0" && textBox29.Text!="1") 
                ||(textBox34.Text!="0" && textBox34.Text!="1"))
            {
                SwParTran = false;
                MessageBox.Show("Only 0 and 1 can be chosen as ParTran");
            }

            if ((textBox5.Text != "t" && textBox5.Text != "T" && textBox5.Text !="f" && textBox5.Text !="F") || (textBox10.Text != "t" && textBox10.Text != "T" && textBox10.Text !="f" && textBox10.Text !="F")
                || (textBox15.Text != "t" && textBox15.Text != "T" && textBox15.Text !="f" && textBox15.Text !="F") || (textBox20.Text != "t" && textBox20.Text != "T" && textBox20.Text !="f" && textBox20.Text !="F")
                ||(textBox25.Text != "t" && textBox25.Text != "T" && textBox25.Text !="f" && textBox25.Text !="F")||(textBox30.Text != "t" && textBox30.Text != "T" && textBox30.Text !="f" && textBox30.Text !="F")
                ||(textBox35.Text != "t" && textBox35.Text != "T" && textBox35.Text !="f" && textBox35.Text !="F"))
            {
                SwParFit = false;
                MessageBox.Show("Please input the right ParFit");
            }

            if ((T001Val < T002Val || T001Val > T003Val) || (T0smth01Val < T0smth02Val || T0smth01Val > T0smth03Val)
                ||(Wcorr01Val<Wcorr02Val || Wcorr01Val>Wcorr03Val) || (Tm01Val<Tm02Val || Tm01Val>Tm03Val)
                || (Tmsmth01Val<Tmsmth02Val || Tmsmth01Val>Tmsmth03Val) || (Kw01Val<Kw02Val || Kw01Val>Kw03Val)
                || (Swsmth01Val<Swsmth02Val || Swsmth01Val>Swsmth03Val) || (Sw01Val<Sw02Val || Sw01Val>Sw03Val))
            {
                SwScale = false;
                MessageBox.Show("Please input the right scale!");
            }

            if (SwValue==true && SwParFit==true && SwParTran==true && SwScale==true)
            {
                Form1.T001 = textBox1.Text;
                Form1.T002 = textBox2.Text;
                Form1.T003 = textBox3.Text;
                Form1.T004 = textBox4.Text;
                Form1.T005 = textBox5.Text;
                Form1.T0smth01 = textBox6.Text;
                Form1.T0smth02 = textBox7.Text;
                Form1.T0smth03 = textBox8.Text;
                Form1.T0smth04 = textBox9.Text;
                Form1.T0smth05 = textBox10.Text;
                Form1.wCorr01 = textBox11.Text;
                Form1.wCorr02 = textBox12.Text;
                Form1.wCorr03 = textBox13.Text;
                Form1.wCorr04 = textBox14.Text;
                Form1.wCorr05 = textBox15.Text;
                Form1.Tm01 = textBox16.Text;
                Form1.Tm02 = textBox17.Text;
                Form1.Tm03 = textBox18.Text;
                Form1.Tm04 = textBox19.Text;
                Form1.Tm05 = textBox20.Text;
                Form1.Tmsmth01 = textBox21.Text;
                Form1.Tmsmth02 = textBox22.Text;
                Form1.Tmsmth03 = textBox23.Text;
                Form1.Tmsmth04 = textBox24.Text;
                Form1.Tmsmth05 = textBox25.Text;
                Form1.Km01 = textBox26.Text;
                Form1.Km02 = textBox27.Text;
                Form1.Km03 = textBox28.Text;
                Form1.Km04 = textBox29.Text;
                Form1.Km05 = textBox30.Text;
                Form1.Swsmth01 = textBox31.Text;
                Form1.Swsmth02 = textBox32.Text;
                Form1.Swsmth03 = textBox33.Text;
                Form1.Swsmth04 = textBox34.Text;
                Form1.Swsmth05 = textBox35.Text;

                Form1.InitialSw = textBox36.Text;
                Form1.LowestSw = textBox37.Text;
                Form1.HighestSw = textBox38.Text;

                Form1.T0check = this.checkBox1.Checked;
                Form1.T0smthcheck = this.checkBox2.Checked;
                Form1.wCorrcheck = this.checkBox3.Checked;
                Form1.Tmcheck = this.checkBox4.Checked;
                Form1.Tmsmthcheck = this.checkBox5.Checked;
                Form1.Kwcheck = this.checkBox6.Checked;
                Form1.Swsmthcheck = this.checkBox7.Checked;

                this.Close();
            }
        }

        private void Sw_Load(object sender, EventArgs e)
        {

            //textBox1.Enabled = false;
            //textBox2.Enabled = false;
            //textBox3.Enabled = false;
            //textBox4.Enabled = false;
            //textBox5.Enabled = false;
            //textBox6.Enabled = false;
            //textBox7.Enabled = false;
            //textBox8.Enabled = false;
            //textBox9.Enabled = false;
            //textBox10.Enabled = false;
            //textBox11.Enabled = false;
            //textBox12.Enabled = false;
            //textBox13.Enabled = false;
            //textBox14.Enabled = false;
            //textBox15.Enabled = false;
            //textBox16.Enabled = false;
            //textBox17.Enabled = false;
            //textBox18.Enabled = false;
            //textBox19.Enabled = false;
            //textBox20.Enabled = false;
            //textBox21.Enabled = false;
            //textBox22.Enabled = false;
            //textBox23.Enabled = false;
            //textBox24.Enabled = false;
            //textBox25.Enabled = false;
            //textBox26.Enabled = false;
            //textBox27.Enabled = false;
            //textBox28.Enabled = false;
            //textBox29.Enabled = false;
            //textBox30.Enabled = false;
            //textBox31.Enabled = false;
            //textBox32.Enabled = false;
            //textBox33.Enabled = false;
            //textBox34.Enabled = false;
            //textBox35.Enabled = false;

            textBox1.Text = "3.5";
            textBox2.Text = "0.0";
            textBox3.Text = "10.0";
            textBox4.Text = "0";
            textBox5.Text = "T";
            textBox6.Text = "1.5";
            textBox7.Text = "1.e-2";
            textBox8.Text = "2.0";
            textBox9.Text = "1";
            textBox10.Text = "T";
            textBox11.Text = "3.0";
            textBox12.Text = "0.5";
            textBox13.Text = "5.0";
            textBox14.Text = "0";
            textBox15.Text = "T";
            textBox16.Text = "1.5";
            textBox17.Text = "0.0";
            textBox18.Text = "4.0";
            textBox19.Text = "0";
            textBox20.Text = "T";
            textBox21.Text = "1.5";
            textBox22.Text = "1.e-2";
            textBox23.Text = "2.0";
            textBox24.Text = "1";
            textBox25.Text = "T";
            textBox26.Text = "2.0";
            textBox27.Text = "1.e-2";
            textBox28.Text = "10.0";
            textBox29.Text = "1";
            textBox30.Text = "T";
            textBox31.Text = "0.5";
            textBox32.Text = "1.e-2";
            textBox33.Text = "2.0";
            textBox34.Text = "1";
            textBox35.Text = "T"; 
        }



        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
            }
            else
            {
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                textBox5.Enabled = true;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == false)
            {
                textBox6.Enabled = false;
                textBox7.Enabled = false;
                textBox8.Enabled = false;
                textBox9.Enabled = false;
                textBox10.Enabled = false;
            }
            else
            {
                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;
                textBox9.Enabled = true;
                textBox10.Enabled = true;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked == false)
            {
                textBox11.Enabled = false;
                textBox12.Enabled = false;
                textBox13.Enabled = false;
                textBox14.Enabled = false;
                textBox15.Enabled = false;
            }
            else
            {
                textBox11.Enabled = true;
                textBox12.Enabled = true;
                textBox13.Enabled = true;
                textBox14.Enabled = true;
                textBox15.Enabled = true;
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked == false)
            {
                textBox16.Enabled = false;
                textBox17.Enabled = false;
                textBox18.Enabled = false;
                textBox19.Enabled = false;
                textBox20.Enabled = false;
            }
            else
            {
                textBox16.Enabled = true;
                textBox17.Enabled = true;
                textBox18.Enabled = true;
                textBox19.Enabled = true;
                textBox20.Enabled = true;
            }
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked == false)
            {
                textBox21.Enabled = false;
                textBox22.Enabled = false;
                textBox23.Enabled = false;
                textBox24.Enabled = false;
                textBox25.Enabled = false;
            }
            else
            {
                textBox21.Enabled = true;
                textBox22.Enabled = true;
                textBox23.Enabled = true;
                textBox24.Enabled = true;
                textBox25.Enabled = true;
            }
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked == false)
            {
                textBox26.Enabled = false;
                textBox27.Enabled = false;
                textBox28.Enabled = false;
                textBox29.Enabled = false;
                textBox30.Enabled = false;
            }
            else
            {
                textBox26.Enabled = true;
                textBox27.Enabled = true;
                textBox28.Enabled = true;
                textBox29.Enabled = true;
                textBox30.Enabled = true;
            }
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox7.Checked == false)
            {
                textBox31.Enabled = false;
                textBox32.Enabled = false;
                textBox33.Enabled = false;
                textBox34.Enabled = false;
                textBox35.Enabled = false;
            }
            else
            {
                textBox31.Enabled = true;
                textBox32.Enabled = true;
                textBox33.Enabled = true;
                textBox34.Enabled = true;
                textBox35.Enabled = true;
            }
        }

        private void textBox36_TextChanged(object sender, EventArgs e)
        {
            Form1.InitialSw = textBox36.Text;
        }

        private void textBox37_TextChanged(object sender, EventArgs e)
        {
            Form1.LowestSw = textBox37.Text;
        }

        private void textBox38_TextChanged(object sender, EventArgs e)
        {
            Form1.HighestSw = textBox38.Text;
        }



        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox21_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
