﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;


namespace FLEX_interface
{
    public partial class ME : Form
    {
        public ME()
        {
            InitializeComponent();
        }

        double eMult01Val;
        double eMult02Val;
        double eMult03Val;

        private void button1_Click(object sender, EventArgs e)
        {
            bool MEValue = true;
            bool MEParTran = true;
            bool MEParFit = true;
            bool MEScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match eMult01Eva = science.Match(textBox1.Text);
            Match eMult02Eva = science.Match(textBox2.Text);
            Match eMult03Eva = science.Match(textBox3.Text);


            if (!eMult01Eva.Success || !eMult02Eva.Success || !eMult03Eva.Success)
            {
                MEValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                eMult01Val = Convert.ToDouble(textBox1.Text);
                eMult02Val = Convert.ToDouble(textBox2.Text);
                eMult03Val = Convert.ToDouble(textBox3.Text);
            }

            if (eMult01Val < eMult02Val || eMult01Val > eMult03Val)
            {
                MEScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if (textBox4.Text != "0" && textBox4.Text != "1")
            {
                MEParTran=false ;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if(textBox5.Text!="t" && textBox5.Text!="T" && textBox5.Text!="F" && textBox5.Text!="f")
            {
                MEParFit=false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (MEValue == true && MEParTran == true && MEParFit == true && MEScale==true)
            { 
            Form1.eMult01 = textBox1.Text;
            Form1.eMult02 = textBox2.Text;
            Form1.eMult03 = textBox3.Text;
            Form1.eMult04 = textBox4.Text;
            Form1.eMult05 = textBox5.Text;

            this.Close();
            
            }

        }
    }
}
