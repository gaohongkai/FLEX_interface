﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class CR : Form
    {
        public CR()
        {
            InitializeComponent();
        }

        double Fr01Val;
        double Fr02Val;
        double Fr03Val;

        private void button1_Click(object sender, EventArgs e)
        {
        
            bool FrValue = true;
            bool FrParTran = true;
            bool FrParFit = true;
            bool FrScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Fr01Eva = science.Match(textBox1.Text);
            Match Fr02Eva = science.Match(textBox2.Text);
            Match Fr03Eva = science.Match(textBox3.Text);


            if (!Fr01Eva.Success || !Fr02Eva.Success || !Fr03Eva.Success)
            {
                FrValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Fr01Val = Convert.ToDouble(textBox1.Text);
                Fr02Val = Convert.ToDouble(textBox2.Text);
                Fr03Val = Convert.ToDouble(textBox3.Text);
            }

            if (Fr01Val < Fr02Val || Fr01Val > Fr03Val)
            {
                FrScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if (textBox4.Text != "0" && textBox4.Text != "1")
            {
                FrParTran=false ;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if(textBox5.Text!="t" && textBox5.Text!="T" && textBox5.Text!="F" && textBox5.Text!="f")
            {
                FrParFit=false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (FrValue == true && FrParTran == true && FrParFit == true && FrScale==true)
            { 
            Form1.Fr01 = textBox1.Text;
            Form1.Fr02 = textBox2.Text;
            Form1.Fr03 = textBox3.Text;
            Form1.Fr04 = textBox4.Text;
            Form1.Fr05 = textBox5.Text;

            this.Close();
            
            }
        }


    }
}
