﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class Sfr : Form
    {
        public Sfr()
        {
            InitializeComponent();
        }

        double Kr01Val;
        double Kr02Val;
        double Kr03Val;
        double SRInitialVal;
        double SRLowVal;
        double SRHighVal;

        private void Sfr_Load(object sender, EventArgs e)
        {
            //textBox6.Enabled = false;
            //textBox7.Enabled = false;
            //textBox8.Enabled = false;
            //textBox9.Enabled = false;
            //textBox10.Enabled = false;


            textBox6.Text = "1.0";
            textBox7.Text = "5.e-2";
            textBox8.Text = "4.0";
            textBox9.Text = "1";
            textBox10.Text = "T";
        }

        private void button1_Click(object sender, EventArgs e)
        {

            bool SRValue = true;
            bool SRParTran = true;
            bool SRParFit = true;
            bool SRScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Kr01Eva = science.Match(textBox6.Text);
            Match Kr02Eva = science.Match(textBox7.Text);
            Match Kr03Eva = science.Match(textBox8.Text);
            Match SRInitEva = science.Match(textBox1.Text);
            Match SRLowEva = science.Match(textBox2.Text);
            Match SRHighEva = science.Match(textBox3.Text);


            if (!Kr01Eva.Success || !Kr02Eva.Success || !Kr03Eva.Success || !SRInitEva.Success || !SRLowEva.Success || !SRHighEva.Success)
            {
                SRValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Kr01Val = Convert.ToDouble(textBox6.Text);
                Kr02Val = Convert.ToDouble(textBox7.Text);
                Kr03Val = Convert.ToDouble(textBox8.Text);
                SRInitialVal = Convert.ToDouble(textBox1.Text);
                SRLowVal = Convert.ToDouble(textBox2.Text);
                SRHighVal = Convert.ToDouble(textBox3.Text);
            }

            if ((Kr01Val < Kr02Val || Kr01Val > Kr03Val) || (SRInitialVal < SRLowVal|| SRInitialVal > SRHighVal))
            {
                SRScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if (textBox9.Text != "0" && textBox9.Text != "1")
            {
                SRParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if (textBox10.Text != "t" && textBox10.Text != "T" && textBox10.Text != "F" && textBox10.Text != "f")
            {
                SRParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (SRValue == true && SRParTran == true && SRParFit == true && SRScale == true)
            {

                Form1.Kr01 = textBox6.Text;
                Form1.Kr02 = textBox7.Text;
                Form1.Kr03 = textBox8.Text;
                Form1.Kr04 = textBox9.Text;
                Form1.Kr05 = textBox10.Text;

                Form1.Krcheck = this.checkBox1.Checked;

                this.Close();
            }


        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                textBox6.Enabled = false;
                textBox7.Enabled = false;
                textBox8.Enabled = false;
                textBox9.Enabled = false;
                textBox10.Enabled = false;
                Form1.Kscheck = false;
            }
            else
            {
                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;
                textBox9.Enabled =true;
                textBox10.Enabled = true;
                Form1.Kscheck = true;
            }
        }



    }
}
