﻿namespace FLEX_interface
{
    partial class Su
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Su));
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.constructiveFunctionForAToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zeroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refPowToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logisticToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.quadroidToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.expToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hyperExpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.con2linToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tessierToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.michMentesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lin2conToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.construcToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zeroToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.linearToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.constructiveFunctionForEToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.zeroToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.linearToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.powerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.refPowToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.expToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.hyperExpToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.con2linToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.tessierToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.michMentesToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.lin2conToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Epar";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 68);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(41, 12);
            this.label3.TabIndex = 2;
            this.label3.Text = "Su,max";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 98);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(29, 12);
            this.label5.TabIndex = 4;
            this.label5.Text = "Pmax";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(15, 128);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(29, 12);
            this.label7.TabIndex = 6;
            this.label7.Text = "Beta";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(15, 158);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(41, 12);
            this.label8.TabIndex = 7;
            this.label8.Text = "Center";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(88, 19);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 12);
            this.label9.TabIndex = 8;
            this.label9.Text = "Value";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(131, 19);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 12);
            this.label10.TabIndex = 9;
            this.label10.Text = "ParLo";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(174, 19);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 12);
            this.label11.TabIndex = 10;
            this.label11.Text = "ParHi";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(262, 18);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(41, 12);
            this.label12.TabIndex = 11;
            this.label12.Text = "parFit";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(217, 18);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(47, 12);
            this.label13.TabIndex = 12;
            this.label13.Text = "ParTran";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(84, 38);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(43, 21);
            this.textBox1.TabIndex = 13;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(129, 38);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(43, 21);
            this.textBox2.TabIndex = 14;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(174, 38);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(43, 21);
            this.textBox3.TabIndex = 15;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(219, 38);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(43, 21);
            this.textBox4.TabIndex = 16;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(264, 38);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(43, 21);
            this.textBox5.TabIndex = 17;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(84, 68);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(43, 21);
            this.textBox11.TabIndex = 23;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(129, 68);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(43, 21);
            this.textBox12.TabIndex = 24;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(174, 68);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(43, 21);
            this.textBox13.TabIndex = 25;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(219, 68);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(43, 21);
            this.textBox14.TabIndex = 26;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(264, 68);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(43, 21);
            this.textBox15.TabIndex = 27;
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(84, 98);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(43, 21);
            this.textBox21.TabIndex = 33;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(129, 98);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(43, 21);
            this.textBox22.TabIndex = 34;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(174, 98);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(43, 21);
            this.textBox23.TabIndex = 35;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(219, 98);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(43, 21);
            this.textBox24.TabIndex = 36;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(264, 98);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(43, 21);
            this.textBox25.TabIndex = 37;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(84, 128);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(43, 21);
            this.textBox31.TabIndex = 43;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(129, 128);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(43, 21);
            this.textBox32.TabIndex = 44;
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(174, 128);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(43, 21);
            this.textBox33.TabIndex = 45;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(219, 128);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(43, 21);
            this.textBox34.TabIndex = 46;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(264, 128);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(43, 21);
            this.textBox35.TabIndex = 47;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(84, 158);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(43, 21);
            this.textBox36.TabIndex = 48;
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(129, 158);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(43, 21);
            this.textBox37.TabIndex = 49;
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(174, 158);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(43, 21);
            this.textBox38.TabIndex = 50;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(219, 158);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(43, 21);
            this.textBox39.TabIndex = 51;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(264, 158);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(43, 21);
            this.textBox40.TabIndex = 52;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(562, 290);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 53;
            this.button1.Text = "OK";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(63, 38);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(15, 14);
            this.checkBox1.TabIndex = 54;
            this.checkBox1.UseVisualStyleBackColor = true;
            this.checkBox1.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Checked = true;
            this.checkBox2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox2.Location = new System.Drawing.Point(63, 69);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(15, 14);
            this.checkBox2.TabIndex = 55;
            this.checkBox2.UseVisualStyleBackColor = true;
            this.checkBox2.CheckedChanged += new System.EventHandler(this.checkBox2_CheckedChanged);
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Checked = true;
            this.checkBox3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox3.Location = new System.Drawing.Point(63, 100);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(15, 14);
            this.checkBox3.TabIndex = 56;
            this.checkBox3.UseVisualStyleBackColor = true;
            this.checkBox3.CheckedChanged += new System.EventHandler(this.checkBox3_CheckedChanged);
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Checked = true;
            this.checkBox4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox4.Location = new System.Drawing.Point(63, 131);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(15, 14);
            this.checkBox4.TabIndex = 57;
            this.checkBox4.UseVisualStyleBackColor = true;
            this.checkBox4.CheckedChanged += new System.EventHandler(this.checkBox4_CheckedChanged);
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(63, 162);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(15, 14);
            this.checkBox5.TabIndex = 58;
            this.checkBox5.UseVisualStyleBackColor = true;
            this.checkBox5.CheckedChanged += new System.EventHandler(this.checkBox5_CheckedChanged);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Controls.Add(this.label15);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.textBox43);
            this.groupBox4.Controls.Add(this.textBox42);
            this.groupBox4.Controls.Add(this.textBox41);
            this.groupBox4.Location = new System.Drawing.Point(434, 230);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(315, 54);
            this.groupBox4.TabIndex = 62;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "State";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(209, 25);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(47, 12);
            this.label16.TabIndex = 5;
            this.label16.Text = "Highest";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(111, 24);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(41, 12);
            this.label15.TabIndex = 4;
            this.label15.Text = "Lowest";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(3, 25);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(47, 12);
            this.label14.TabIndex = 3;
            this.label14.Text = "Initial";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(262, 22);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(45, 21);
            this.textBox43.TabIndex = 2;
            this.textBox43.Text = "1.e4";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(158, 22);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(45, 21);
            this.textBox42.TabIndex = 1;
            this.textBox42.Text = "0.0";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(56, 22);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(45, 21);
            this.textBox41.TabIndex = 0;
            this.textBox41.Text = "100.0";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label1);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.checkBox5);
            this.groupBox5.Controls.Add(this.checkBox4);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Controls.Add(this.checkBox3);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.checkBox2);
            this.groupBox5.Controls.Add(this.label9);
            this.groupBox5.Controls.Add(this.checkBox1);
            this.groupBox5.Controls.Add(this.label10);
            this.groupBox5.Controls.Add(this.label11);
            this.groupBox5.Controls.Add(this.textBox40);
            this.groupBox5.Controls.Add(this.label12);
            this.groupBox5.Controls.Add(this.textBox39);
            this.groupBox5.Controls.Add(this.label13);
            this.groupBox5.Controls.Add(this.textBox38);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Controls.Add(this.textBox37);
            this.groupBox5.Controls.Add(this.textBox2);
            this.groupBox5.Controls.Add(this.textBox36);
            this.groupBox5.Controls.Add(this.textBox3);
            this.groupBox5.Controls.Add(this.textBox35);
            this.groupBox5.Controls.Add(this.textBox4);
            this.groupBox5.Controls.Add(this.textBox34);
            this.groupBox5.Controls.Add(this.textBox5);
            this.groupBox5.Controls.Add(this.textBox33);
            this.groupBox5.Controls.Add(this.textBox32);
            this.groupBox5.Controls.Add(this.textBox31);
            this.groupBox5.Controls.Add(this.textBox11);
            this.groupBox5.Controls.Add(this.textBox12);
            this.groupBox5.Controls.Add(this.textBox13);
            this.groupBox5.Controls.Add(this.textBox25);
            this.groupBox5.Controls.Add(this.textBox14);
            this.groupBox5.Controls.Add(this.textBox24);
            this.groupBox5.Controls.Add(this.textBox15);
            this.groupBox5.Controls.Add(this.textBox23);
            this.groupBox5.Controls.Add(this.textBox22);
            this.groupBox5.Controls.Add(this.textBox21);
            this.groupBox5.Location = new System.Drawing.Point(434, 28);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(315, 196);
            this.groupBox5.TabIndex = 63;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Parameters";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.InitialImage = ((System.Drawing.Image)(resources.GetObject("pictureBox4.InitialImage")));
            this.pictureBox4.Location = new System.Drawing.Point(213, 64);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(201, 50);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 70;
            this.pictureBox4.TabStop = false;
            this.pictureBox4.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(12, 160);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(186, 151);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 64;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(12, 46);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(185, 108);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 65;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(274, 73);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(154, 50);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 69;
            this.pictureBox3.TabStop = false;
            this.pictureBox3.Visible = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(203, 72);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(201, 50);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 71;
            this.pictureBox5.TabStop = false;
            this.pictureBox5.Visible = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(203, 64);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(201, 50);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 73;
            this.pictureBox7.TabStop = false;
            this.pictureBox7.Visible = false;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(203, 72);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(201, 50);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox8.TabIndex = 74;
            this.pictureBox8.TabStop = false;
            this.pictureBox8.Visible = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.menuStrip1.GripStyle = System.Windows.Forms.ToolStripGripStyle.Visible;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.constructiveFunctionForAToolStripMenuItem,
            this.construcToolStripMenuItem,
            this.constructiveFunctionForEToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(756, 25);
            this.menuStrip1.TabIndex = 75;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked);
            // 
            // constructiveFunctionForAToolStripMenuItem
            // 
            this.constructiveFunctionForAToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zeroToolStripMenuItem,
            this.linearToolStripMenuItem,
            this.fdToolStripMenuItem,
            this.refPowToolStripMenuItem,
            this.logisticToolStripMenuItem,
            this.quadroidToolStripMenuItem,
            this.expToolStripMenuItem,
            this.hyperExpToolStripMenuItem,
            this.con2linToolStripMenuItem,
            this.tessierToolStripMenuItem,
            this.michMentesToolStripMenuItem,
            this.lin2conToolStripMenuItem});
            this.constructiveFunctionForAToolStripMenuItem.Name = "constructiveFunctionForAToolStripMenuItem";
            this.constructiveFunctionForAToolStripMenuItem.Size = new System.Drawing.Size(174, 21);
            this.constructiveFunctionForAToolStripMenuItem.Text = "Constructive function for A";
            // 
            // zeroToolStripMenuItem
            // 
            this.zeroToolStripMenuItem.Name = "zeroToolStripMenuItem";
            this.zeroToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.zeroToolStripMenuItem.Text = "zero";
            this.zeroToolStripMenuItem.Click += new System.EventHandler(this.zeroToolStripMenuItem_Click);
            // 
            // linearToolStripMenuItem
            // 
            this.linearToolStripMenuItem.Name = "linearToolStripMenuItem";
            this.linearToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.linearToolStripMenuItem.Text = "linear";
            this.linearToolStripMenuItem.Click += new System.EventHandler(this.linearToolStripMenuItem_Click);
            // 
            // fdToolStripMenuItem
            // 
            this.fdToolStripMenuItem.Name = "fdToolStripMenuItem";
            this.fdToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.fdToolStripMenuItem.Text = "power";
            this.fdToolStripMenuItem.Click += new System.EventHandler(this.fdToolStripMenuItem_Click);
            // 
            // refPowToolStripMenuItem
            // 
            this.refPowToolStripMenuItem.Name = "refPowToolStripMenuItem";
            this.refPowToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.refPowToolStripMenuItem.Text = "refPow";
            this.refPowToolStripMenuItem.Click += new System.EventHandler(this.refPowToolStripMenuItem_Click);
            // 
            // logisticToolStripMenuItem
            // 
            this.logisticToolStripMenuItem.Name = "logisticToolStripMenuItem";
            this.logisticToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.logisticToolStripMenuItem.Text = "logistic";
            this.logisticToolStripMenuItem.Click += new System.EventHandler(this.logisticToolStripMenuItem_Click);
            // 
            // quadroidToolStripMenuItem
            // 
            this.quadroidToolStripMenuItem.Name = "quadroidToolStripMenuItem";
            this.quadroidToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.quadroidToolStripMenuItem.Text = "quadroid";
            this.quadroidToolStripMenuItem.Click += new System.EventHandler(this.quadroidToolStripMenuItem_Click);
            // 
            // expToolStripMenuItem
            // 
            this.expToolStripMenuItem.Name = "expToolStripMenuItem";
            this.expToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.expToolStripMenuItem.Text = "exp";
            this.expToolStripMenuItem.Click += new System.EventHandler(this.expToolStripMenuItem_Click);
            // 
            // hyperExpToolStripMenuItem
            // 
            this.hyperExpToolStripMenuItem.Name = "hyperExpToolStripMenuItem";
            this.hyperExpToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.hyperExpToolStripMenuItem.Text = "hyperExp";
            this.hyperExpToolStripMenuItem.Click += new System.EventHandler(this.hyperExpToolStripMenuItem_Click);
            // 
            // con2linToolStripMenuItem
            // 
            this.con2linToolStripMenuItem.Name = "con2linToolStripMenuItem";
            this.con2linToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.con2linToolStripMenuItem.Text = "con2lin";
            this.con2linToolStripMenuItem.Click += new System.EventHandler(this.con2linToolStripMenuItem_Click);
            // 
            // tessierToolStripMenuItem
            // 
            this.tessierToolStripMenuItem.Name = "tessierToolStripMenuItem";
            this.tessierToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.tessierToolStripMenuItem.Text = "tessier";
            this.tessierToolStripMenuItem.Click += new System.EventHandler(this.tessierToolStripMenuItem_Click);
            // 
            // michMentesToolStripMenuItem
            // 
            this.michMentesToolStripMenuItem.Name = "michMentesToolStripMenuItem";
            this.michMentesToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.michMentesToolStripMenuItem.Text = "michMentes";
            this.michMentesToolStripMenuItem.Click += new System.EventHandler(this.michMentesToolStripMenuItem_Click);
            // 
            // lin2conToolStripMenuItem
            // 
            this.lin2conToolStripMenuItem.Name = "lin2conToolStripMenuItem";
            this.lin2conToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.lin2conToolStripMenuItem.Text = "lin2con";
            this.lin2conToolStripMenuItem.Click += new System.EventHandler(this.lin2conToolStripMenuItem_Click);
            // 
            // construcToolStripMenuItem
            // 
            this.construcToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zeroToolStripMenuItem1,
            this.linearToolStripMenuItem1});
            this.construcToolStripMenuItem.Name = "construcToolStripMenuItem";
            this.construcToolStripMenuItem.Size = new System.Drawing.Size(174, 21);
            this.construcToolStripMenuItem.Text = "Constructive function for B";
            // 
            // zeroToolStripMenuItem1
            // 
            this.zeroToolStripMenuItem1.Name = "zeroToolStripMenuItem1";
            this.zeroToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.zeroToolStripMenuItem1.Text = "zero";
            this.zeroToolStripMenuItem1.Click += new System.EventHandler(this.zeroToolStripMenuItem1_Click);
            // 
            // linearToolStripMenuItem1
            // 
            this.linearToolStripMenuItem1.Name = "linearToolStripMenuItem1";
            this.linearToolStripMenuItem1.Size = new System.Drawing.Size(108, 22);
            this.linearToolStripMenuItem1.Text = "linear";
            this.linearToolStripMenuItem1.Click += new System.EventHandler(this.linearToolStripMenuItem1_Click);
            // 
            // constructiveFunctionForEToolStripMenuItem
            // 
            this.constructiveFunctionForEToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.zeroToolStripMenuItem2,
            this.linearToolStripMenuItem2,
            this.powerToolStripMenuItem,
            this.refPowToolStripMenuItem1,
            this.expToolStripMenuItem1,
            this.hyperExpToolStripMenuItem1,
            this.con2linToolStripMenuItem1,
            this.tessierToolStripMenuItem1,
            this.michMentesToolStripMenuItem1,
            this.lin2conToolStripMenuItem1});
            this.constructiveFunctionForEToolStripMenuItem.Name = "constructiveFunctionForEToolStripMenuItem";
            this.constructiveFunctionForEToolStripMenuItem.Size = new System.Drawing.Size(173, 21);
            this.constructiveFunctionForEToolStripMenuItem.Text = "Constructive function for E";
            // 
            // zeroToolStripMenuItem2
            // 
            this.zeroToolStripMenuItem2.Name = "zeroToolStripMenuItem2";
            this.zeroToolStripMenuItem2.Size = new System.Drawing.Size(146, 22);
            this.zeroToolStripMenuItem2.Text = "zero";
            this.zeroToolStripMenuItem2.Click += new System.EventHandler(this.zeroToolStripMenuItem2_Click);
            // 
            // linearToolStripMenuItem2
            // 
            this.linearToolStripMenuItem2.Name = "linearToolStripMenuItem2";
            this.linearToolStripMenuItem2.Size = new System.Drawing.Size(146, 22);
            this.linearToolStripMenuItem2.Text = "linear";
            this.linearToolStripMenuItem2.Click += new System.EventHandler(this.linearToolStripMenuItem2_Click);
            // 
            // powerToolStripMenuItem
            // 
            this.powerToolStripMenuItem.Name = "powerToolStripMenuItem";
            this.powerToolStripMenuItem.Size = new System.Drawing.Size(146, 22);
            this.powerToolStripMenuItem.Text = "power";
            this.powerToolStripMenuItem.Click += new System.EventHandler(this.powerToolStripMenuItem_Click);
            // 
            // refPowToolStripMenuItem1
            // 
            this.refPowToolStripMenuItem1.Name = "refPowToolStripMenuItem1";
            this.refPowToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.refPowToolStripMenuItem1.Text = "refPow";
            this.refPowToolStripMenuItem1.Click += new System.EventHandler(this.refPowToolStripMenuItem1_Click);
            // 
            // expToolStripMenuItem1
            // 
            this.expToolStripMenuItem1.Name = "expToolStripMenuItem1";
            this.expToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.expToolStripMenuItem1.Text = "exp";
            this.expToolStripMenuItem1.Click += new System.EventHandler(this.expToolStripMenuItem1_Click);
            // 
            // hyperExpToolStripMenuItem1
            // 
            this.hyperExpToolStripMenuItem1.Name = "hyperExpToolStripMenuItem1";
            this.hyperExpToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.hyperExpToolStripMenuItem1.Text = "hyperExp";
            this.hyperExpToolStripMenuItem1.Click += new System.EventHandler(this.hyperExpToolStripMenuItem1_Click);
            // 
            // con2linToolStripMenuItem1
            // 
            this.con2linToolStripMenuItem1.Name = "con2linToolStripMenuItem1";
            this.con2linToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.con2linToolStripMenuItem1.Text = "con2lin";
            this.con2linToolStripMenuItem1.Click += new System.EventHandler(this.con2linToolStripMenuItem1_Click);
            // 
            // tessierToolStripMenuItem1
            // 
            this.tessierToolStripMenuItem1.Name = "tessierToolStripMenuItem1";
            this.tessierToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.tessierToolStripMenuItem1.Text = "tessier";
            this.tessierToolStripMenuItem1.Click += new System.EventHandler(this.tessierToolStripMenuItem1_Click);
            // 
            // michMentesToolStripMenuItem1
            // 
            this.michMentesToolStripMenuItem1.Name = "michMentesToolStripMenuItem1";
            this.michMentesToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.michMentesToolStripMenuItem1.Text = "michMentes";
            this.michMentesToolStripMenuItem1.Click += new System.EventHandler(this.michMentesToolStripMenuItem1_Click);
            // 
            // lin2conToolStripMenuItem1
            // 
            this.lin2conToolStripMenuItem1.Name = "lin2conToolStripMenuItem1";
            this.lin2conToolStripMenuItem1.Size = new System.Drawing.Size(146, 22);
            this.lin2conToolStripMenuItem1.Text = "lin2con";
            this.lin2conToolStripMenuItem1.Click += new System.EventHandler(this.lin2conToolStripMenuItem1_Click);
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(203, 64);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(201, 68);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 72;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(203, 200);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(180, 50);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 76;
            this.pictureBox9.TabStop = false;
            this.pictureBox9.Visible = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(203, 200);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(201, 50);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 77;
            this.pictureBox10.TabStop = false;
            this.pictureBox10.Visible = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox11.Image")));
            this.pictureBox11.Location = new System.Drawing.Point(203, 200);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(201, 50);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox11.TabIndex = 78;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(203, 200);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(184, 50);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 79;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Visible = false;
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox13.Image")));
            this.pictureBox13.Location = new System.Drawing.Point(205, 200);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(184, 50);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox13.TabIndex = 80;
            this.pictureBox13.TabStop = false;
            this.pictureBox13.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(203, 46);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(167, 12);
            this.label2.TabIndex = 81;
            this.label2.Text = "constructive function for A";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(211, 173);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(167, 12);
            this.label4.TabIndex = 82;
            this.label4.Text = "constructive function for E";
            // 
            // Su
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(756, 320);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.pictureBox7);
            this.Controls.Add(this.pictureBox6);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox5);
            this.Controls.Add(this.pictureBox4);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Su";
            this.Text = "Su";
            this.Load += new System.EventHandler(this.Su_Load);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem constructiveFunctionForAToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem construcToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zeroToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linearToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refPowToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logisticToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem quadroidToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem expToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hyperExpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem con2linToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tessierToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem michMentesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lin2conToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zeroToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem linearToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem constructiveFunctionForEToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem zeroToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem linearToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem powerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem refPowToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem expToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem hyperExpToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem con2linToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem tessierToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem michMentesToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem lin2conToolStripMenuItem1;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
    }
}