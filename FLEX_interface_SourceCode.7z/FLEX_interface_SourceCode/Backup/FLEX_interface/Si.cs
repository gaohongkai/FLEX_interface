﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Text.RegularExpressions;



namespace FLEX_interface
{
    public partial class Si : Form
    {
        public Si()
        {
            InitializeComponent();
        }

        //public string batFileName;

        private void Si_Load(object sender, EventArgs e)
        {
            //textBox1.Enabled = false;
            //textBox2.Enabled = false;
            //textBox3.Enabled = false;
            //textBox4.Enabled = false;
            //textBox5.Enabled = false;
            //textBox6.Enabled = false;
            //textBox7.Enabled = false;
            //textBox8.Enabled = false;
            //textBox9.Enabled = false;
            //textBox10.Enabled = false;
  


            textBox1.Text = "10.0";
            textBox2.Text = "1.e-2";
            textBox3.Text = "10.0";
            textBox4.Text = "1";
            textBox5.Text = "T";
            textBox6.Text = "1.e-1";
            textBox7.Text = "1.e-3";
            textBox8.Text = "1.0";
            textBox9.Text = "1";
            textBox10.Text = "F";


        }

        double Imax01Val;
        double Imax02Val;
        double Imax03Val;
        double Ismth01Val;
        double Ismth02Val;
        double Ismth03Val;
        double SIInitialVal;
        double SILowVal;
        double SIHighVal;

        private void button1_Click(object sender, EventArgs e)
        {

            bool SIValue = true;
            bool SIParTran = true;
            bool SIParFit = true;
            bool SIScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Imax01Eva = science.Match(textBox1.Text);
            Match Imax02Eva = science.Match(textBox2.Text);
            Match Imax03Eva = science.Match(textBox3.Text);
            Match Ismth01Eva = science.Match(textBox6.Text);
            Match Ismth02Eva = science.Match(textBox7.Text);
            Match Ismth03Eva = science.Match(textBox8.Text);
            
            Match SIInitEva = science.Match(textBox11.Text);
            Match SILowEva = science.Match(textBox12.Text);
            Match SIHighEva = science.Match(textBox13.Text);


            if (!Imax01Eva.Success || !Imax02Eva.Success || !Imax03Eva.Success || !Ismth01Eva.Success 
                || !Ismth02Eva.Success || !Ismth03Eva.Success || !SIInitEva.Success || !SILowEva.Success || !SIHighEva.Success)
            {
                SIValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Imax01Val = Convert.ToDouble(textBox1.Text);
                Imax02Val = Convert.ToDouble(textBox2.Text);
                Imax03Val = Convert.ToDouble(textBox3.Text);
                Ismth01Val = Convert.ToDouble(textBox6.Text);
                Ismth02Val = Convert.ToDouble(textBox7.Text);
                Ismth03Val = Convert.ToDouble(textBox8.Text);
                SIInitialVal = Convert.ToDouble(textBox11.Text);
                SILowVal = Convert.ToDouble(textBox12.Text);
                SIHighVal = Convert.ToDouble(textBox13.Text);
            }

            if ((Imax01Val < Imax02Val || Imax01Val > Imax03Val) || (Ismth01Val < Ismth02Val || Ismth01Val > Ismth03Val) ||(SIInitialVal < SILowVal || SIInitialVal > SIHighVal))
            {
                SIScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if ((textBox4.Text != "0" && textBox4.Text != "1") || (textBox9.Text != "0" && textBox9.Text != "1"))
            {
                SIParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if ((textBox10.Text != "t" && textBox10.Text != "T" && textBox10.Text != "F" && textBox10.Text != "f") || 
                (textBox5.Text != "t" && textBox5.Text != "T" && textBox5.Text != "F" && textBox5.Text != "f"))
            {
                SIParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (SIValue == true && SIParTran == true && SIParFit == true && SIScale == true)
            {

            Form1.Imax01 = textBox1.Text;
            Form1.Imax02 = textBox2.Text;
            Form1.Imax03 = textBox3.Text;
            Form1.Imax04 = textBox4.Text;
            Form1.Imax05 = textBox5.Text;
            Form1.IRsmth01 = textBox6.Text;
            Form1.IRsmth02 = textBox7.Text;
            Form1.IRsmth03 = textBox8.Text;
            Form1.IRsmth04 = textBox9.Text;
            Form1.IRsmth05 = textBox10.Text;

            Form1.InitialSi = textBox11.Text;
            Form1.LowestSi = textBox12.Text;
            Form1.HighestSi = textBox13.Text;

            Form1.Imaxcheck = this.checkBox2.Checked;
            Form1.IRsmthcheck = this.checkBox3.Checked;

            if (radioButton1.Checked == true)
            {
                Form1.IRsmooth = 2;
            }
            if (radioButton2.Checked == true)
            {
                Form1.IRsmooth = 21;
            }
            if (radioButton3.Checked == true)
            {
                Form1.EIR = 0;
            }
            if (radioButton4.Checked == true)
            {
                Form1.EIR = -1;
            }

            this.Close();
            }


        }



        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == false)
            {
                textBox1.Enabled = false;
                textBox2.Enabled = false;
                textBox3.Enabled = false;
                textBox4.Enabled = false;
                textBox5.Enabled = false;
                Form1.Imaxcheck = false;
            }
            else
            {
                textBox1.Enabled = true;
                textBox2.Enabled = true;
                textBox3.Enabled = true;
                textBox4.Enabled = true;
                textBox5.Enabled = true;
                Form1.Imaxcheck = true;
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if(checkBox3.Checked==false)
           {
                textBox6.Enabled = false;
                textBox7.Enabled = false;
                textBox8.Enabled = false;
                textBox9.Enabled = false;
                textBox10.Enabled = false;

                Form1.IRsmthcheck = false;
            }
            else
            {
                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;
                textBox9.Enabled = true;
                textBox10.Enabled = true;

                Form1.IRsmthcheck = true;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {

        }



    }
}
