﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class CS : Form
    {
        public CS()
        {
            InitializeComponent();
        }
        
        double D01Val;
        double D02Val;
        double D03Val;

        private void button1_Click(object sender, EventArgs e)
        {
            bool DValue = true;
            bool DParTran = true;
            bool DParFit = true;
            bool DScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match D01Eva = science.Match(textBox1.Text);
            Match D02Eva = science.Match(textBox2.Text);
            Match D03Eva = science.Match(textBox3.Text);


            if (!D01Eva.Success || !D02Eva.Success || !D03Eva.Success)
            {
                DValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                D01Val = Convert.ToDouble(textBox1.Text);
                D02Val = Convert.ToDouble(textBox2.Text);
                D03Val = Convert.ToDouble(textBox3.Text);
            }

            if (D01Val < D02Val || D01Val > D03Val)
            {
                DScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if (textBox4.Text != "0" && textBox4.Text != "1")
            {
                DParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if (textBox5.Text != "t" && textBox5.Text != "T" && textBox5.Text != "F" && textBox5.Text != "f")
            {
                DParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (DValue == true && DParTran == true && DParFit == true && DScale == true)
            {
                Form1.D01 = textBox1.Text;
                Form1.D02 = textBox2.Text;
                Form1.D03 = textBox3.Text;
                Form1.D04 = textBox4.Text;
                Form1.D05 = textBox5.Text;

                this.Close();

            }

        }
    }
}
