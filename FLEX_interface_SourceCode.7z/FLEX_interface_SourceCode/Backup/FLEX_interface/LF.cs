﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class LF : Form
    {
        public LF()
        {
            InitializeComponent();
        }

        double Peakf01Val;
        double Peakf02Val;
        double Peakf03Val;
        double Gam01Val;
        double Gam02Val;
        double Gam03Val;

        private void button1_Click(object sender, EventArgs e)
        {
            bool LFValue = true;
            bool LFParTran = true;
            bool LFParFit = true;
            bool LFScale = true;
            bool LFNumCon = true;

            Regex science = new Regex(@"^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Peakf01Eva = science.Match(textBox2.Text);
            Match Peakf02Eva = science.Match(textBox3.Text);
            Match Peakf03Eva = science.Match(textBox4.Text);
            Match Gam01Eva = science.Match(textBox7.Text);
            Match Gam02Eva = science.Match(textBox8.Text);
            Match Gam03Eva = science.Match(textBox9.Text);

            Regex i = new Regex(@"^\d*$"); //int regular expression
            Match NumCon = i.Match(textBox1.Text);

            if (!NumCon.Success && textBox1.Text != "-1")
            {
                LFNumCon = false;
                MessageBox.Show("Please input a proper Convolution Number!");
            }

            if (!Peakf01Eva.Success || !Peakf02Eva.Success || !Peakf03Eva.Success || !Gam01Eva.Success || !Gam02Eva.Success || !Gam03Eva.Success)
            {
                LFValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Peakf01Val = Convert.ToDouble(textBox2.Text);
                Peakf02Val = Convert.ToDouble(textBox3.Text);
                Peakf03Val = Convert.ToDouble(textBox4.Text);
                Gam01Val = Convert.ToDouble(textBox7.Text);
                Gam02Val = Convert.ToDouble(textBox8.Text);
                Gam03Val = Convert.ToDouble(textBox9.Text);
            }

            if ((Peakf01Val < Peakf02Val || Peakf01Val > Peakf03Val) || (Gam01Val<Gam02Val || Gam01Val>Gam03Val))
            {
                LFScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if ((textBox5.Text != "0" && textBox5.Text != "1") || (textBox10.Text != "0" && textBox10.Text != "1"))
            {
                LFParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if ((textBox6.Text != "t" && textBox6.Text != "T" && textBox6.Text != "F" && textBox6.Text != "f") 
                || (textBox11.Text != "t" && textBox11.Text != "T" && textBox11.Text != "F" && textBox11.Text != "f"))
            {
                LFParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (LFValue == true && LFParTran == true && LFParFit == true && LFScale == true && LFNumCon==true)
            {
                Form1.ConvolutionNumLF = int.Parse(textBox1.Text);
                Form1.Peakf01 = textBox2.Text;
                Form1.Peakf02 = textBox3.Text;
                Form1.Peakf03 = textBox4.Text;
                Form1.Peakf04 = textBox5.Text;
                Form1.Peakf05 = textBox6.Text;
                Form1.Gam01 = textBox7.Text;
                Form1.Gam02 = textBox8.Text;
                Form1.Gam03 = textBox9.Text;
                Form1.Gam04 = textBox10.Text;
                Form1.Gam05 = textBox11.Text;

                if (radioButton1.Checked == true)
                {
                    Form1.lagsmthLF = -1;
                }
                if (radioButton2.Checked == true)
                {
                    Form1.lagsmthLF = 0;
                }
                if (radioButton3.Checked == true)
                {
                    Form1.lagsmthLF = 1;
                }
                if (radioButton4.Checked == true)
                {
                    Form1.lagsmthLF = 2;
                }

                this.Close();
            }

            

        }
    }
}
