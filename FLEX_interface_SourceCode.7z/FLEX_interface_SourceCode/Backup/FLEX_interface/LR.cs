﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class LR : Form
    {
        public LR()
        {
            InitializeComponent();
        }

        double Peakr01Val;
        double Peakr02Val;
        double Peakr03Val;

        private void button1_Click(object sender, EventArgs e)
        {
            bool LRValue = true;
            bool LRParTran = true;
            bool LRParFit = true;
            bool LRScale = true;
            bool LRNumCon = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Peakr01Eva = science.Match(textBox2.Text);
            Match Peakr02Eva = science.Match(textBox3.Text);
            Match Peakr03Eva = science.Match(textBox4.Text);


            Regex i = new Regex(@"^\d*$"); //int regular expression
            Match NumCon = i.Match(textBox1.Text);

            if (!NumCon.Success && textBox1.Text != "-1")
            {
                LRNumCon = false;
                MessageBox.Show("Please input a proper Convolution Number!");
            }

            if (!Peakr01Eva.Success || !Peakr02Eva.Success || !Peakr03Eva.Success)
            {
                LRValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Peakr01Val = Convert.ToDouble(textBox2.Text);
                Peakr02Val = Convert.ToDouble(textBox3.Text);
                Peakr03Val = Convert.ToDouble(textBox4.Text);
            }

            if ((Peakr01Val < Peakr02Val || Peakr01Val > Peakr03Val))
            {
                LRScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if ((textBox5.Text != "0" && textBox5.Text != "1"))
            {
                LRParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if ((textBox6.Text != "t" && textBox6.Text != "T" && textBox6.Text != "F" && textBox6.Text != "f"))
            {
                LRParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (LRValue == true && LRParTran == true && LRParFit == true && LRScale == true && LRNumCon == true)
            {

                Form1.ConvolutionNumLR = int.Parse(textBox1.Text);
                Form1.Peakr01 = textBox2.Text;
                Form1.Peakr02 = textBox3.Text;
                Form1.Peakr03 = textBox4.Text;
                Form1.Peakr04 = textBox5.Text;
                Form1.Peakr05 = textBox6.Text;

                if (radioButton1.Checked == true)
                {
                    Form1.lagsmthLR = -1;

                }
                if (radioButton2.Checked == true)
                {
                    Form1.lagsmthLR = 0;
                }
                if (radioButton3.Checked == true)
                {
                    Form1.lagsmthLR = 1;
                }
                if (radioButton4.Checked == true)
                {
                    Form1.lagsmthLR = 2;
                }

                this.Close();
            }

        }
    }
}
