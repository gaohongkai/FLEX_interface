﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace FLEX_interface
{
    public partial class Sr : Form
    {
        public Sr()
        {
            InitializeComponent();
        }
    }
}
