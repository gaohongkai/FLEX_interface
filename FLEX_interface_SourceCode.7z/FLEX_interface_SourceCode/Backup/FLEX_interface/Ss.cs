﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class Ss : Form
    {
        public Ss()
        {
            InitializeComponent();
        }

        double Ks01Val;
        double Ks02Val;
        double Ks03Val;
        double Alfas01Val;
        double Alfas02Val;
        double Alfas03Val;

        double SSInitialVal;
        double SSLowVal;
        double SSHighVal;

        private void button1_Click(object sender, EventArgs e)
        {

            
            bool SSValue = true;
            bool SSParTran = true;
            bool SSParFit = true;
            bool SSScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Ks01Eva = science.Match(textBox6.Text);
            Match Ks02Eva = science.Match(textBox7.Text);
            Match Ks03Eva = science.Match(textBox8.Text);
            Match Alfas01Eva = science.Match(textBox11.Text);
            Match Alfas02Eva = science.Match(textBox12.Text);
            Match Alfas03Eva = science.Match(textBox13.Text);

            Match SSInitEva = science.Match(textBox16.Text);
            Match SSLowEva = science.Match(textBox17.Text);
            Match SSHighEva = science.Match(textBox18.Text);


            if (!Ks01Eva.Success || !Ks02Eva.Success || !Ks03Eva.Success
                || !Alfas01Eva.Success || !Alfas02Eva.Success || !Alfas03Eva.Success
                || !SSInitEva.Success || !SSLowEva.Success || !SSHighEva.Success)
            {
                SSValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Ks01Val = Convert.ToDouble(textBox6.Text);
                Ks02Val = Convert.ToDouble(textBox7.Text);
                Ks03Val = Convert.ToDouble(textBox8.Text);
                Alfas01Val = Convert.ToDouble(textBox11.Text);
                Alfas02Val = Convert.ToDouble(textBox12.Text);
                Alfas03Val = Convert.ToDouble(textBox13.Text);
                SSInitialVal = Convert.ToDouble(textBox16.Text);
                SSLowVal = Convert.ToDouble(textBox17.Text);
                SSHighVal = Convert.ToDouble(textBox18.Text);
            }

            if ((Ks01Val < Ks02Val || Ks01Val > Ks03Val)
                || (Alfas01Val < Alfas02Val || Alfas01Val > Alfas03Val)
                || (SSInitialVal < SSLowVal|| SSInitialVal > SSHighVal))
            {
                SSScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if ((textBox9.Text != "0" && textBox9.Text != "1") || (textBox14.Text != "0" && textBox14.Text != "1"))
            {
                SSParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if ((textBox10.Text != "t" && textBox10.Text != "T" && textBox10.Text != "F" && textBox10.Text != "f") 
                || (textBox10.Text != "t" && textBox10.Text != "T" && textBox10.Text != "F" && textBox10.Text != "f"))
            {
                SSParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (SSValue == true && SSParTran == true && SSParFit == true && SSScale == true)
            {

                Form1.Ks01 = textBox6.Text;
                Form1.Ks02 = textBox7.Text;
                Form1.Ks03 = textBox8.Text;
                Form1.Ks04 = textBox9.Text;
                Form1.Ks05 = textBox10.Text;
                Form1.alfaS01 = textBox11.Text;
                Form1.alfaS02 = textBox12.Text;
                Form1.alfaS03 = textBox13.Text;
                Form1.alfaS04 = textBox14.Text;
                Form1.alfaS05 = textBox15.Text;

                Form1.InitialSs = textBox16.Text;
                Form1.LowestSs = textBox17.Text;
                Form1.HighestSs = textBox18.Text;

                Form1.Kscheck = this.checkBox1.Checked;
                Form1.alfaScheck = this.checkBox2.Checked;

                this.Close();
            }


        }

        private void Ss_Load(object sender, EventArgs e)
        {
            //textBox6.Enabled = false;
            //textBox7.Enabled = false;
            //textBox8.Enabled = false;
            //textBox9.Enabled = false;
            //textBox10.Enabled = false;
            //textBox11.Enabled = false;
            //textBox12.Enabled = false;
            //textBox13.Enabled = false;
            //textBox14.Enabled = false;
            //textBox15.Enabled = false;

            textBox6.Text = "1.0e-3";
            textBox7.Text = "1.e-7";
            textBox8.Text = "1.0";
            textBox9.Text = "1";
            textBox10.Text = "T";
            textBox11.Text = "1.0";
            textBox12.Text = "1.e-2";
            textBox13.Text = "10.0";
            textBox14.Text = "1";
            textBox15.Text = "T"; 
    
        }

 


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked == false)
            {
                textBox6.Enabled = false;
                textBox7.Enabled = false;
                textBox8.Enabled = false;
                textBox9.Enabled = false;
                textBox10.Enabled = false;
                Form1.Kscheck = false;
            }
            else
            {
                textBox6.Enabled = true;
                textBox7.Enabled = true;
                textBox8.Enabled = true;
                textBox9.Enabled = true;
                textBox10.Enabled = true;
                Form1.Kscheck = true;
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked == false)
            {
                textBox11.Enabled = false;
                textBox12.Enabled = false;
                textBox13.Enabled = false;
                textBox14.Enabled = false;
                textBox15.Enabled = false;
                Form1.alfaScheck = false;
            }
            else
            {
                textBox11.Enabled = true;
                textBox12.Enabled = true;
                textBox13.Enabled = true;
                textBox14.Enabled = true;
                textBox15.Enabled = true;
                Form1.alfaScheck = true;
            }
        }

    }
}
