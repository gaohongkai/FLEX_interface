﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

namespace FLEX_interface
{
    public partial class CreateFilePath : Form
    {
        public static int activePar = 5;
        public static int fixedPar = 0;
        public static int deadPar = 0;
        public static int reservoirs = 0;
        public static string batFileName = @"D:\Downloads\flexConfig.dat";
        public static string line01;
        public static string line02;
        public static string line03;
        public static string line04;
        public static string line05;
        public static string line06;
        public static string line07;
        public static string line08;
        public static string line09;
        public static string line10;
        public static string line11;
        public static string line12;
        public static string line13;
        public static string line14;
        public static string line15;
        public static string line16;
        public static string line17;
        public static string line18;
        public static string line19;
        public static string line20;
        public static string line21;
        public static string line22;
        public static string line23;
        public static string line24;
        public static string line25;
        public static string line26;
        public static string line27;
        public static string line28;
        public static string line29;
        public static string line30;
        public static string line31;
        public static string line32;
        public static string line33;
        public static string line34;
        public static string line35;
        public static string line36;
        public static string line37;
        public static string line38;
        public static string line39;
        public static string line40;
        public static string line41;

        public static string line50;
        public static string line51;
        public static string line52;
        public static string line53;
        public static string line54;
        public static string line55;
        public static string line56;
        public static string line57;
        public static string line58;
        public static string line59;
        public static string line60;
        public static string line61;
        public static string line62;
        public static string line63;
        public static string line64;
        public static string line65;
        public static string line66;
        

/*
        string getbatFileName()
        {
            return batFileName;
        }
  */      
        public CreateFilePath()
        {
            InitializeComponent();
            textBox1.Text=@"C:\BATEAU_DEMO\flexConfig";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //SaveFileDialog fbDlgg = new SaveFileDialog();
            //fbDlgg.Filter  = "txt files (*.txt)|*.txt|All files (*.*)|*.*";
            //fbDlgg .FilterIndex = 2;
            //fbDlgg.RestoreDirectory = true;

            //if (fbDlgg .ShowDialog == DialogResult.OK )
            //{
            //    if ((myStream == fbDlgg .OpenFile) != null)
            //    {
            //        StreamWriter wText = new StreamWriter(myStream);

            //        wText.Write(" your text");

            //        myStream.Close();
            //    }
            //}
            FolderBrowserDialog fbDlg = new FolderBrowserDialog();
            fbDlg.Description = "请选择工作路径";
            fbDlg.SelectedPath = @"C:\BATEAU_DEMO";

            if (fbDlg.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = fbDlg.SelectedPath;
            }
        }
 
         private void button2_Click(object sender, EventArgs e)
         {
             batFileName=textBox1.Text + "\\flexConfig.dat";
             StreamWriter tst = new StreamWriter(batFileName);
             tst.WriteLine("FLEX_CONFIGURATION_FILE_V1.6");
             tst.WriteLine("! Description: FLEX-SPAM model configuration file");
             tst.WriteLine("!========");
             tst.WriteLine("05         ! index describing model configuration (for ease of reference/documentation)");
             tst.WriteLine("'M05' ! nametag describing model configuration (eg, 'stdFLEX/powerAS', etc)");
             tst.WriteLine("!========");
             tst.WriteLine("FLEX RESERVOIR STATUS AND CONSTITUTIVE RELATIONSHIPS");
            
             if (Form1.formcheck2 == false)
             {
                 tst.WriteLine(".false. ! enableWR");
                 
             }
             else
             {
                 tst.WriteLine(".true. ! enableWR");
                 reservoirs = reservoirs + 1;
             }

             if (Form1.formcheck1 == false)
             {
                 tst.WriteLine(".false.  ! enableIR    ! UR-A-ID: supported= 0,1,2,3,10,11,20,21,22,30,31,32");
             }
             else
             {
                 tst.WriteLine(".true.  ! enableIR    ! UR-A-ID: supported= 0,1,2,3,10,11,20,21,22,30,31,32");
                 reservoirs = reservoirs + 1;
             }

             if (Form1.formcheck4 == false)
             {
                 tst.WriteLine(".false.  ! enableRR    ! UR-B-ID: supported= 0,1 (more options easy to add)");
             }
             else
             {
                 tst.WriteLine(".true.  ! enableRR    ! UR-B-ID: supported= 0,1 (more options easy to add)");
                 reservoirs = reservoirs + 1;
             }

             if (Form1.formcheck3 == false)
             {
                 tst.WriteLine(".false.  ! enableUR     ! ");
             }
             else
             {
                 tst.WriteLine(".true.  ! enableUR     ! ");
                 reservoirs = reservoirs + 1;
             }


             if (Form1.formcheck5 == false)
             {
                 tst.WriteLine(".false.  ! enableFR    ! UR-E-ID: supported= 0,1,2,3,20,21,22,30,31,32");

             }
             else
             {
                 tst.WriteLine(".true.  ! enableFR    ! UR-E-ID: supported= 0,1,2,3,20,21,22,30,31,32");
                 reservoirs = reservoirs + 1;
             }

             if (Form1.formcheck6 == false)
             {
                 tst.WriteLine(".false.  ! enableSR    ! UR-D-ID: supported= 0");

             }
             else
             {
                 tst.WriteLine(".true.  ! enableSR    ! UR-D-ID: supported= 0");
                 reservoirs = reservoirs + 1;
             }
             
             line50=Form1.URFunA+","+Form1.URFunB+","+Form1.URFunE+","+Form1.URFunD;
             tst.WriteLine(line50);
             line51 = Form1.EIR + "," + Form1.IRsmooth;
             tst.WriteLine(line51);
             line52 = Convert.ToString(Form1.FSFun); // int to string
             tst.WriteLine(line52);
             tst.WriteLine("-1           ! SuperFast LAGsmthID (Lag function smoothing)");
             tst.WriteLine("1           ! Fast LAGsmthID (Lag function smoothing)");
             tst.WriteLine("-1           ! Slow LAGsmthID: -1=original, 0=quadrature, 1=midpoint, 2=trapezoidal");
             tst.WriteLine("!========");
             tst.WriteLine("POSSIBILITY OF SUBSTITUTING FR TO FS");
             tst.WriteLine(".true.  ! use FS instead of FR if FR is enabled: Uses then parameters km,kp,ksmt,ediv insead of kf and alfa.");
             tst.WriteLine("!========");
             tst.WriteLine("FLEX NUMERICS");
             tst.WriteLine("1       ! numerical solver for interception reservoir (0=odeint, 1=fixed-spm-implicit, 2=bounded EE, -1=simple-threshold, -2=algebraic-statique)");
             tst.WriteLine("3       ! numerical solver for simple reservoirs (0=odeint, 3=fixed-liebre-implicit, 2=bounded EE)");
             tst.WriteLine("1       ! numerical solver for UR zone (0=odeint, 1=fixed-spm-implicit, 2=bounded EE)");
             tst.WriteLine("!========");
             tst.WriteLine("FLEX CONFIGURATION INFORMATION");
             if (Form1.Imaxcheck == true)
                 Form1.activePar += 1;
             if (Form1.IRsmthcheck == true)
                 Form1.activePar += 1;
             if (Form1.EFSsmcheck == true)
                 Form1.activePar += 1;
             if (Form1.Kfcheck == true)
                 Form1.activePar += 1;
             if (Form1.alfaFcheck == true)
                 Form1.activePar += 1;
             if (Form1.Kmcheck == true)
                 Form1.activePar += 1;
             if (Form1.Kpcheck == true)
                 Form1.activePar += 1;
             if (Form1.Sfbcheck == true)
                 Form1.activePar += 1;
             if (Form1.Ksmtcheck == true)
                 Form1.activePar += 1;
             if (Form1.ETparcheck == true)
                 Form1.activePar += 1;
             if (Form1.Sumaxcheck == true)
                 Form1.activePar += 1;
             if (Form1.Pmxcheck == true)
                 Form1.activePar += 1;
             if (Form1.Betacheck == true)
                 Form1.activePar += 1;
             if (Form1.Centercheck == true)
                 Form1.activePar += 1;
             if (Form1.T0check == true)
                 Form1.activePar += 1;
             if (Form1.T0smthcheck == true)
                 Form1.activePar += 1;
             if (Form1.wCorrcheck == true)
                 Form1.activePar += 1;
             if (Form1.Tmcheck == true)
                 Form1.activePar += 1;
             if (Form1.Tmsmthcheck == true)
                 Form1.activePar += 1;
             if (Form1.Kwcheck == true)
                 Form1.activePar += 1;
             if (Form1.Swsmthcheck == true)
                 Form1.activePar += 1;
             if (Form1.Krcheck == true)
                 Form1.activePar += 1;
             if (Form1.Kscheck == true)
                 Form1.activePar += 1;
             if (Form1.alfaScheck == true)
                 Form1.activePar += 1;

             Form1.activePar += 8;
             Form1.deadPar = 32 - Form1.activePar;

             line62 = Form1.activePar + "       " + "! number of active parameters";
             tst.WriteLine(line62);
             tst.WriteLine("0    ! number of fixed parameters");
             line63 = Form1.deadPar + "       " + "! number of dead parameters";
             tst.WriteLine(line63);
             tst.WriteLine("5    ! number of reservoir states");
             line53 = Convert.ToString(Form1.ConvolutionNumLR);
             tst.WriteLine(line53);
             line54 = Convert .ToString  (Form1.ConvolutionNumLF);
             tst.WriteLine(line54);
             line55 = Convert .ToString (Form1.ConvolutionNumLS);
             tst.WriteLine(line55);
             tst.WriteLine("!========");
             tst.WriteLine("ACTIVE_PARAMETER_INFO (parameters visible to BATEA)");

tst.WriteLine("parName           parDef            parLo         parHi      parScal     parSD         parTran   parFit    Comment");
line10 = "\"rMult,- \"" + "    " + Form1.rMult01 + "    " + Form1.rMult02 + "    " + Form1.rMult03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.rMult04 + "    " + Form1.rMult05 + "    " + "(cannot be dead) Rainfall multiplication factor";
tst.WriteLine(line10);
line03 = "\"eMult,- \"" + "    " + Form1.eMult01 + "   " + Form1.eMult02 + "   " + Form1.eMult03 + "   " + "10.0" + "   " + "-9999.9" + "   " + Form1.eMult04 + "   " + Form1.eMult05 + "(cannot be dead) Multiplication factor for evaporation";
tst.WriteLine(line03);

if (Form1.T0smthcheck == true)
{
    line19 = "\"T0smth,-\"" + "    " + Form1.T0smth01 + "    " + Form1.T0smth02 + "    " + Form1.T0smth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.T0smth04 + "    " + Form1.T0smth05 + "    " + "Sw";
    tst.WriteLine(line19);
}
if (Form1.Tmsmthcheck == true)
{
    line20 = "\"Tmsmth,-\"" + "    " + Form1.Tmsmth01 + "    " + Form1.Tmsmth02 + "    " + Form1.Tmsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tmsmth04 + "    " + Form1.Tmsmth05 + "    " + "Sw";
    tst.WriteLine(line20);
}
if (Form1.Swsmthcheck == true)
{
    line21 = "\"Swsmth,-\"" + "    " + Form1.Swsmth01 + "    " + Form1.Swsmth02 + "    " + Form1.Swsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Swsmth04 + "    " + Form1.Swsmth05 + "    " + "Sw";
    tst.WriteLine(line21);
}
if (Form1.Kwcheck == true)
{
    line22 = "\"Kw,mm/ct\"" + "    " + Form1.Kw01 + "    " + Form1.Kw02 + "    " + Form1.Kw03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kw04 + "    " + Form1.Kw05 + "    " + "Sw";
    tst.WriteLine(line22);
}
if (Form1.wCorrcheck == true)
{
    line23 = "\"wCorr,- \"" + "    " + Form1.wCorr01 + "    " + Form1.wCorr02 + "    " + Form1.wCorr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.wCorr04 + "    " + Form1.wCorr05 + "    " + "Sw";
    tst.WriteLine(line23);
}
if (Form1.Tmcheck == true)
{
    line24 = "\"Tm, C   \"" + "    " + Form1.Tm01 + "    " + Form1.Tm02 + "    " + Form1.Tm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw";
    tst.WriteLine(line24);
}
if (Form1.T0check == true)
{
    line25 = "\"T0, C   \"" + "    " + Form1.T001 + "    " + Form1.T002 + "    " + Form1.T003 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw";
    tst.WriteLine(line25);
}

if (Form1.Imaxcheck == true)
{
    line31 = "\"Imax, mm\"" + "    " + Form1.Imax01 + "    " + Form1.Imax02 + "    " + Form1.Imax03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Imax04 + "    " + Form1.Imax05 + "    " + "Si";
    tst.WriteLine(line31);
}
if (Form1.IRsmthcheck == true)
{
    line32 = "\"IRsmth,-\"" + "    " + Form1.IRsmth01 + "    " + Form1.IRsmth02 + "    " + Form1.IRsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.IRsmth04 + "    " + Form1.IRsmth05 + "    " + "Si";
    tst.WriteLine(line32);
}

//line08 = tst.WriteLine(line08);
if (Form1.Sumaxcheck == true)
{
    line01 = "\"Sumax,mm\"" + "       " + Form1.Sumax01 + "             " + Form1.Sumax02 + "              " + Form1.Sumax03 + "           " + "10.0" + "        " + "-9999.9" + "    " + Form1.Sumax04 + "       " + Form1.Sumax05 + "       " + "Su";
    tst.WriteLine(line01);
}
if (Form1.Betacheck == true)
{

    line02 = "\"Beta, - \"" + "          " + Form1.Beta01 + "    " + Form1.Beta02 + "    " + Form1.Beta03 + "    " + "10.0" + "    " + "-9999.9" + "   " + Form1.Beta04 + "  " + Form1.Beta05 + " " + "Su  (logistic & quadroid) Beta->0 gives stronger step-threshold in UR A(S) function";
    tst.WriteLine(line02);
}
if (Form1.Pmxcheck == true)
{
    line15 = "\"Pmx,mm/t\"" + "    " + Form1.Pmx01 + "    " + Form1.Pmx02 + "    " + Form1.Pmx03 + "    " + "10.0" + "    " + "-9999.0" + "    " + Form1.Pmx04 + "    " + Form1.Pmx05 + "       " + "Su";
    tst.WriteLine(line15);
}
if (Form1.Centercheck == true)
{
    line07 = "\"Center,-\"" + "    " + Form1.Center01 + "    " + Form1.Center02 + "    " + Form1.Center03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Center04 + "    " + Form1.Center05 + "    " + "Su";
    tst.WriteLine(line07);
}

line06 = "\"Peakf, t\"" + "    " + Form1.Peakf01 + "    " + Form1.Peakf02 + "    " + Form1.Peakf03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Peakf04 + "    " + Form1.Peakf05 + "    " + "Sf (cannot be dead) when LAGsmthID=1, nStateConv>peakF[hi] to avoid chopping recession of lag function";
tst.WriteLine(line06);

if (Form1.FSFun == 23)
{
    if (Form1.EFSsmcheck == true)
    {
        line16 = "\"EFSsm,mm\"" + "    " + Form1.EFSsm01 + "    " + Form1.EFSsm02 + "    " + Form1.EFSsm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.EFSsm04 + "    " + Form1.EFSsm05 + "    " + "Sf Smoothing factor for evaporation (only FS)";
        tst.WriteLine(line16);
    }
    if (Form1.Ksmtcheck == true)
    {
        line27 = "\"Ksmt,1/t\"" + "    " + Form1.Ksmt01 + "    " + Form1.Ksmt02 + "    " + Form1.Ksmt03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ksmt04 + "    " + Form1.Ksmt05 + "    " + "Sf";
        tst.WriteLine(line27);
    }
    if (Form1.Kmcheck == true)
    {
        line28 = "\"Km, 1/t \"" + "    " + Form1.Km01 + "    " + Form1.Km02 + "    " + Form1.Km03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Km04 + "    " + Form1.Km05 + "    " + "Sf";
        tst.WriteLine(line28);
    }
    if (Form1.Kpcheck == true)
    {
        line29 = "\"Kp, 1/t \"" + "    " + Form1.Kp01 + "    " + Form1.Kp02 + "    " + Form1.Kp03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kp04 + "    " + Form1.Kp05 + "    " + "Sf";
        tst.WriteLine(line29);
    }
    if (Form1.Sfbcheck == true)
    {
        line30 = "\"Sfb, mm \"" + "    " + Form1.Sfb01 + "    " + Form1.Sfb02 + "    " + Form1.Sfb03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Sfb04 + "    " + Form1.Sfb05 + "    " + "Sf";
        tst.WriteLine(line30);
    }
}
if (Form1.FSFun == 2)
{
    if (Form1.Kfcheck == true)
    {
        line04 = "\"Kf, 1/t \"" + "    " + Form1.Kf01 + "  " + Form1.Kf02 + "  " + Form1.Kf03 + "  " + "10.0" + "  " + "-9999.9" + "   " + Form1.Kf04 + "  " + Form1.Kf05 + "       " + "Sf";
        tst.WriteLine(line04);
    }
    if (Form1.alfaFcheck == true)
    {
        line05 = "\"alfaF,- \"" + "    " + Form1.alfaF01 + "  " + Form1.alfaF02 + "  " + Form1.alfaF03 + "  " + "10.0" + "  " + "-9999.9" + "  " + Form1.alfaF04 + "  " + Form1.alfaF05 + "  " + "Sf";
        tst.WriteLine(line05);
    }
}

line09 = "\"D, -    \"" + "    " + Form1.D01 + "    " + Form1.D02 + "    " + Form1.D03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.D04 + "    " + Form1.D05 + "    " + "(cannot be dead) D->1 diverts input from Fast convolution store to Slow convolution store";
tst.WriteLine(line09);
line11 = "\"Fr, -   \"" + "    " + Form1.Fr01 + "    " + Form1.Fr02 + "    " + Form1.Fr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Fr04 + "    " + Form1.Fr05 + "       " + "Su";
tst.WriteLine(line11);

line12 = "\"Peakr, t\"" + "    " + Form1.Peakr01 + "    " + Form1.Peakr02 + "    " + Form1.Peakr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Peakr04 + "    " + Form1.Peakr05 + "    " + " (cannot be dead) when LAGsmthID=1, nStateConv>peakF[hi] to avoid chopping recession of lag function";
tst.WriteLine(line12);
if (Form1.Krcheck == true)
{
    line26 = "\"Kr,1/t  \"" + "    " + Form1.Kr01 + "    " + Form1.Kr02 + "    " + Form1.Kr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kr04 + "    " + Form1.Kr05 + "    " + "Sr";
    tst.WriteLine(line26);
}
line13 = "\"Gam,mm/t\"" + "    " + Form1.Gam01 + "    " + Form1.Gam02 + "    " + Form1.Gam03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Gam04 + "    " + Form1.Gam05;
tst.WriteLine(line13);
line14 = "\"Peaks, t\"" + "    " + Form1.Peaks01 + "    " + Form1.Peaks02 + "    " + Form1.Peaks03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Peaks04 + "    " + Form1.Peaks05;
tst.WriteLine(line14);

if (Form1.Kscheck == true)
{
    line17 = "\"Ks, 1/t \"" + "    " + Form1.Ks01 + "    " + Form1.Ks02 + "    " + Form1.Ks03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ks04 + "    " + Form1.Ks05 + "    " + "Ss";
    tst.WriteLine(line17);
}
if (Form1.alfaScheck == true)
{
    line18 = "\"alfaS,- \"" + "    " + Form1.alfaS01 + "    " + Form1.alfaS02 + "    " + Form1.alfaS03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.alfaS04 + "    " + Form1.alfaS05 + "    " + "Ss";
    tst.WriteLine(line18);
}

tst.WriteLine("!========");
tst.WriteLine("FIXED_PARAMETER_INFO (parameters that exist but are fixed and invisible to BATEA)");
tst.WriteLine("!========");
tst.WriteLine("MORTO_PARAMETER_INFO (parameters that dont exist for this configuration)");

if (Form1.Imaxcheck == false)
{
    line31 = "\"Imax, mm\"" + "    " + Form1.Imax01 + "    " + Form1.Imax02 + "    " + Form1.Imax03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Imax04 + "    " + Form1.Imax05 + "    " + "Si";
    tst.WriteLine(line31);
}
if (Form1.IRsmthcheck == false)
{
    line32 = "\"IRsmth,-\"" + "    " + Form1.IRsmth01 + "    " + Form1.IRsmth02 + "    " + Form1.IRsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.IRsmth04 + "    " + Form1.IRsmth05 + "    " + "Si";
    tst.WriteLine(line32);
}

if (Form1.Centercheck == false)
{
    line07 = "\"Center,-\"" + "    " + Form1.Center01 + "    " + Form1.Center02 + "    " + Form1.Center03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Center04 + "    " + Form1.Center05 + "    " + "Su";
    tst.WriteLine(line07);
}

if (Form1.Sumaxcheck == false)
{
    line01 = "\"Sumax,mm\"" + "       " + Form1.Sumax01 + "             " + Form1.Sumax02 + "              " + Form1.Sumax03 + "           " + "10.0" + "        " + "-9999.9" + "    " + Form1.Sumax04 + "       " + Form1.Sumax05 + "       " + "Su";
    tst.WriteLine(line01);
}

if (Form1.Betacheck == false)
{

    line02 = "\"Beta, - \"" + "          " + Form1.Beta01 + "    " + Form1.Beta02 + "    " + Form1.Beta03 + "    " + "10.0" + "    " + "-9999.9" + "   " + Form1.Beta04 + "  " + Form1.Beta05 + " " + "Su  (logistic & quadroid) Beta->0 gives stronger step-threshold in UR A(S) function";
    tst.WriteLine(line02);
}
if (Form1.Kscheck == false)
{
    line17 = "\"Ks, 1/t \"" + "    " + Form1.Ks01 + "    " + Form1.Ks02 + "    " + Form1.Ks03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ks04 + "    " + Form1.Ks05 + "    " + "Ss";
    tst.WriteLine(line17);
}
if (Form1.alfaScheck == false)
{
    line18 = "\"alfaS,- \"" + "    " + Form1.alfaS01 + "    " + Form1.alfaS02 + "    " + Form1.alfaS03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.alfaS04 + "    " + Form1.alfaS05 + "    " + "Ss";
    tst.WriteLine(line18);
}
if (Form1.T0smthcheck == false)
{
    line19 = "\"T0smth,-\"" + "    " + Form1.T0smth01 + "    " + Form1.T0smth02 + "    " + Form1.T0smth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.T0smth04 + "    " + Form1.T0smth05 + "    " + "Sw";
    tst.WriteLine(line19);
}
if (Form1.Tmsmthcheck == false)
{
    line20 = "\"Tmsmth,-\"" + "    " + Form1.Tmsmth01 + "    " + Form1.Tmsmth02 + "    " + Form1.Tmsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tmsmth04 + "    " + Form1.Tmsmth05 + "    " + "Sw";
    tst.WriteLine(line20);
}
if (Form1.Swsmthcheck == false)
{
    line21 = "\"Swsmth,-\"" + "    " + Form1.Swsmth01 + "    " + Form1.Swsmth02 + "    " + Form1.Swsmth03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Swsmth04 + "    " + Form1.Swsmth05 + "    " + "Sw";
    tst.WriteLine(line21);
}
if (Form1.Kwcheck == false)
{
    line22 = "\"Kw,mm/ct\"" + "    " + Form1.Kw01 + "    " + Form1.Kw02 + "    " + Form1.Kw03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kw04 + "    " + Form1.Kw05 + "    " + "Sw";
    tst.WriteLine(line22);
}
if (Form1.wCorrcheck == false)
{
    line23 = "\"wCorr,- \"" + "    " + Form1.wCorr01 + "    " + Form1.wCorr02 + "    " + Form1.wCorr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.wCorr04 + "    " + Form1.wCorr05 + "    " + "Sw";
    tst.WriteLine(line23);
}
if (Form1.Tmcheck == false)
{
    line24 = "\"Tm, C   \"" + "    " + Form1.Tm01 + "    " + Form1.Tm02 + "    " + Form1.Tm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw";
    tst.WriteLine(line24);
}
if (Form1.T0check ==false)
{
    line25 = "\"T0, C   \"" + "    " + Form1.T001 + "    " + Form1.T002 + "    " + Form1.T003 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Tm04 + "    " + Form1.Tm05 + "    " + "Sw";
    tst.WriteLine(line25);
}
if (Form1.Krcheck == false)
{
    line26 = "\"Kr,1/t  \"" + "    " + Form1.Kr01 + "    " + Form1.Kr02 + "    " + Form1.Kr03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kr04 + "    " + Form1.Kr05 + "    " + "Sr";
    tst.WriteLine(line26);
}
if (Form1.FSFun == 2)
{

        line16 = "\"EFSsm,mm\"" + "    " + Form1.EFSsm01 + "    " + Form1.EFSsm02 + "    " + Form1.EFSsm03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.EFSsm04 + "    " + Form1.EFSsm05 + "    " + "Sf Smoothing factor for evaporation (only FS)";
        tst.WriteLine(line16);
        line27 = "\"Ksmt,1/t\"" + "    " + Form1.Ksmt01 + "    " + Form1.Ksmt02 + "    " + Form1.Ksmt03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Ksmt04 + "    " + Form1.Ksmt05 + "    " + "Sf";
        tst.WriteLine(line27);
        line28 = "\"Km, 1/t \"" + "    " + Form1.Km01 + "    " + Form1.Km02 + "    " + Form1.Km03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Km04 + "    " + Form1.Km05 + "    " + "Sf";
        tst.WriteLine(line28);
        line29 = "\"Kp, 1/t \"" + "    " + Form1.Kp01 + "    " + Form1.Kp02 + "    " + Form1.Kp03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Kp04 + "    " + Form1.Kp05 + "    " + "Sf";
        tst.WriteLine(line29);
       line30 = "\"Sfb, mm \"" + "    " + Form1.Sfb01 + "    " + Form1.Sfb02 + "    " + Form1.Sfb03 + "    " + "10.0" + "    " + "-9999.9" + "    " + Form1.Sfb04 + "    " + Form1.Sfb05 + "    " + "Sf";
        tst.WriteLine(line30);
    }
else
    {
        line04 = "\"Kf, 1/t \"" + "    " + Form1.Kf01 + "  " + Form1.Kf02 + "  " + Form1.Kf03 + "  " + "10.0" + "  " + "-9999.9" + "   " + Form1.Kf04 + "  " + Form1.Kf05 + "       " + "Sf";
        tst.WriteLine(line04);
        line05 = "\"alfaF,- \"" + "    " + Form1.alfaF01 + "  " + Form1.alfaF02 + "  " + Form1.alfaF03 + "  " + "10.0" + "  " + "-9999.9" + "  " + Form1.alfaF04 + "  " + Form1.alfaF05 + "  " + "Sf";
        tst.WriteLine(line05);
    }



tst.WriteLine("!========                                     ");
tst.WriteLine("STATE INFO");
tst.WriteLine("stateName        stateDef         stateLo       stateHi    stateScal  ");
tst.WriteLine("\"Qstrm\""+"           0.0               0.0          1.e4         10.0");
tst.WriteLine("\"Qpcor\""+"           0.0               0.0          1.e4         10.0");
if (Form1.formcheck5 == true)
{
    line56 = "\"Sf,mm\"" + "      " + Form1.InitialSf + "        " + Form1.LowestSf + "      " + Form1.HighestSf + "      " + "10.0";
    tst.WriteLine(line56);
}
if (Form1.formcheck1== true)
{
    line57 = "\"Si,mm\"" + "       " + Form1.InitialSi + "     " + Form1.LowestSi + "      " + Form1.HighestSi + "     " + "10.0";
    tst.WriteLine(line57);
}
if (Form1.formcheck4 == true)
{
    line58 = "\"Sr,mm\"" + "       " + Form1.InitialSr + "     " + Form1.LowestSr + "      " + Form1.HighestSr + "     " + "10.0";
    tst.WriteLine(line58);
}
if (Form1.formcheck6 == true)
{
    line59 = "\"Ss,mm\"" + "       " + Form1.InitialSs + "     " + Form1.LowestSs + "      " + Form1.HighestSs + "     " + "10.0";
    tst.WriteLine(line59);
}
if (Form1.formcheck3 == true)
{
    line60 = "\"Su,mm\"" + "       " + Form1.InitialSu + "     " + Form1.LowestSu + "      " + Form1.HighestSu + "     " + "10.0";
    tst.WriteLine(line60);
}
if (Form1.formcheck2 == true)
{
    line61 = "\"Sw,mm\"" + "       " + Form1.InitialSw + "     " + Form1.LowestSw + "      " + Form1.HighestSw + "     " + "10.0";
    tst.WriteLine(line61);
}

//tst.WriteLine("");

if (Form1.formcheck5 ==false)
{
    line56 = "\"Sf,mm\"" + "      " + Form1.InitialSf + "        " + Form1.LowestSf + "      " + Form1.HighestSf + "      " + "10.0";
    tst.WriteLine(line56);
}
if (Form1.formcheck1 == false)
{
    line57 = "\"Si,mm\"" + "       " + Form1.InitialSi + "     " + Form1.LowestSi + "      " + Form1.HighestSi + "     " + "10.0";
    tst.WriteLine(line57);
}
if (Form1.formcheck4 == false )
{
    line58 = "\"Sr,mm\"" + "       " + Form1.InitialSr + "     " + Form1.LowestSr + "      " + Form1.HighestSr + "     " + "10.0";
    tst.WriteLine(line58);
}
if (Form1.formcheck6 == false )
{
    line59 = "\"Ss,mm\"" + "       " + Form1.InitialSs + "     " + Form1.LowestSs + "      " + Form1.HighestSs + "     " + "10.0";
    tst.WriteLine(line59);
}
if (Form1.formcheck3 == false)
{
    line60 = "\"Su,mm\"" + "       " + Form1.InitialSu + "     " + Form1.LowestSu + "      " + Form1.HighestSu + "     " + "10.0";
    tst.WriteLine(line60);
}
if (Form1.formcheck2 == false)
{
    line61 = "\"Sw,mm\"" + "       " + Form1.InitialSw + "     " + Form1.LowestSw + "      " + Form1.HighestSw + "     " + "10.0";
    tst.WriteLine(line61);
}

tst.WriteLine("");
             tst.Close();
             this.Close();
         }

        }
}
