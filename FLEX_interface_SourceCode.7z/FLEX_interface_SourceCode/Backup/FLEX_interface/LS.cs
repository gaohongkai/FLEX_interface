﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class LS : Form
    {
        public LS()
        {
            InitializeComponent();
        }

        double Peaks01Val;
        double Peaks02Val;
        double Peaks03Val;

        private void button1_Click(object sender, EventArgs e)
        {
            bool LSValue = true;
            bool LSParTran = true;
            bool LSParFit = true;
            bool LSScale = true;
            bool LSNumCon = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match Peaks01Eva = science.Match(textBox2.Text);
            Match Peaks02Eva = science.Match(textBox3.Text);
            Match Peaks03Eva = science.Match(textBox4.Text);


            Regex i = new Regex(@"^\d*$"); //int regular expression
            Match NumCon = i.Match(textBox1.Text);

            if (!NumCon.Success && textBox1.Text != "-1")
            {
                LSNumCon = false;
                MessageBox.Show("Please input a proper Convolution Number!");
            }

            if (!Peaks01Eva.Success || !Peaks02Eva.Success || !Peaks03Eva.Success)
            {
                LSValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                Peaks01Val = Convert.ToDouble(textBox2.Text);
                Peaks02Val = Convert.ToDouble(textBox3.Text);
                Peaks03Val = Convert.ToDouble(textBox4.Text);
            }

            if ((Peaks01Val < Peaks02Val || Peaks01Val > Peaks03Val))
            {
                LSScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if ((textBox5.Text != "0" && textBox5.Text != "1"))
            {
                LSParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if ((textBox6.Text != "t" && textBox6.Text != "T" && textBox6.Text != "F" && textBox6.Text != "f"))
            {
                LSParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (LSValue == true && LSParTran == true && LSParFit == true && LSScale == true && LSNumCon == true)
            {
                Form1.ConvolutionNumLS = int.Parse(textBox1.Text);
                Form1.Peaks01 = textBox2.Text;
                Form1.Peaks02 = textBox3.Text;
                Form1.Peaks03 = textBox4.Text;
                Form1.Peaks04 = textBox5.Text;
                Form1.Peaks05 = textBox6.Text;

                if (radioButton1.Checked == true)
                {
                    Form1.lagsmthLS = -1;
                }
                if (radioButton2.Checked == true)
                {
                    Form1.lagsmthLS = 0;
                }
                if (radioButton3.Checked == true)
                {
                    Form1.lagsmthLS = 1;
                }
                if (radioButton4.Checked == true)
                {
                    Form1.lagsmthLS = 2;
                }

                this.Close();
            }
        }
    }

}
