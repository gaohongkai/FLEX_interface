﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace FLEX_interface
{
    public partial class MP : Form
    {
        public MP()
        {
            InitializeComponent();
        }

        double rMult01Val;
        double rMult02Val;
        double rMult03Val;

        private void button1_Click(object sender, EventArgs e)
        {
            bool MPValue = true;
            bool MPParTran = true;
            bool MPParFit = true;
            bool MPScale = true;

            Regex science = new Regex(@"[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$");
            Match rMult01Eva = science.Match(textBox1.Text);
            Match rMult02Eva = science.Match(textBox2.Text);
            Match rMult03Eva = science.Match(textBox3.Text);


            if (!rMult01Eva.Success || !rMult02Eva.Success || !rMult03Eva.Success)
            {
                MPValue = false;
                MessageBox.Show("Please input number!");
            }
            else
            {
                rMult01Val = Convert.ToDouble(textBox1.Text);
                rMult02Val = Convert.ToDouble(textBox2.Text);
                rMult03Val = Convert.ToDouble(textBox3.Text);
            }

            if (rMult01Val < rMult02Val || rMult01Val > rMult03Val)
            {
                MPScale = false;
                MessageBox.Show("Please input proper scale!");
            }
            if (textBox4.Text != "0" && textBox4.Text != "1")
            {
                MPParTran = false;
                MessageBox.Show("Only 0 and 1 are right for ParTran!");
            }
            if (textBox5.Text != "t" && textBox5.Text != "T" && textBox5.Text != "F" && textBox5.Text != "f")
            {
                MPParFit = false;
                MessageBox.Show("Only T and F are right for ParFit!");
            }

            if (MPValue == true && MPParTran == true && MPParFit == true && MPScale == true)
            {
                Form1.rMult01 = textBox1.Text;
                Form1.rMult02 = textBox2.Text;
                Form1.rMult03 = textBox3.Text;
                Form1.rMult04 = textBox4.Text;
                Form1.rMult05 = textBox5.Text;

                this.Close();
            }

        }
    }
}
